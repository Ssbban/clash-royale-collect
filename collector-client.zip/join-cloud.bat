@echo off
call "%~dp0start-scraping.bat" --join https://cr-coordinator.mingjiali129.workers.dev %*
