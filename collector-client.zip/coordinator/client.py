"""Collector client. Reads RoyaleAPI and sends records to the user's coordinator.

The coordinator is loopback or the exact HTTPS origin explicitly pinned with --join.
Machine credentials never follow redirects or travel through an environment proxy.

  * It never reads another browser's cookies. It drives its own Chromium profile in
    ~/.cr-scraper, and you log into RoyaleAPI there once. No password is ever seen, typed
    or stored by this program.
  * Every battle it sends carries its raw pages: the /data/replay answer as received and
    the battle's row from the player's history page (card levels, tower troop and level,
    final tower hit points, elixir stats). The coordinator refuses a battle without them.
  * It saves progress after every unit and retries forever on network failure, so closing
    the lid, losing wifi or rebooting costs at most the unit in flight.

    python coordinator/run_local.py        (starts the local coordinator and this client)
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import platform
import random
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from royale import payload as replay_payload                  # noqa: E402
from royale import pipeline                                   # noqa: E402
from royale.transport import (AuthError, ClearanceExpired, Client,  # noqa: E402
                              Pages, RateLimited, retry_after_seconds)
from coordinator import connection, diagnostics               # noqa: E402

# The upstream project's collection server. Named so the refusal is explicit, but any
# destination still needs an explicit saved HTTPS pin (see local_server).
UPSTREAM_SERVERS = connection.UPSTREAM_SERVERS
# This many battles in a row whose pages cannot be turned into a replay means RoyaleAPI's
# page format changed: stop rather than fill the database with unusable records.
MAX_BAD_IN_A_ROW = 10
HISTORY_PAGES_PER_PLAYER = 20
# Replay requests (/data/replay), retries included: one per minute per machine, start to
# start -- that is the endpoint RoyaleAPI rate-limits. The coordinator's
# request_interval_min/max can only make it slower, never faster.
SOURCE_INTERVAL = 60.0
# Every other RoyaleAPI data request (history pages): a random 8-10 s after the previous
# request. Opening pages (startup, the login page, Cloudflare re-checks) is not paced.
DATA_INTERVAL_MIN, DATA_INTERVAL_MAX = 8.0, 10.0
# Uploads to the coordinator: 5 s apart.
SUBMIT_INTERVAL = 5.0
# Coordinator calls never use a proxy. urllib otherwise honours HTTP_PROXY and the system
# proxy even for 127.0.0.1, and every battle plus the token would go to the proxy.
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward a local token or request body to a redirect target.
        return None


DIRECT = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
PINNED_SERVER = None
ACTIVE_LEASES = None
SUBMIT_PACE = None


def local_server(server: str) -> str:
    """Loopback, or the exact saved HTTPS coordinator; refuse before sending credentials."""
    try:
        return connection.allowed_server(server, PINNED_SERVER)
    except ValueError as exc:
        raise SystemExit(str(exc)) from None

HOME = Path.home() / ".cr-scraper"
PROFILE = HOME / "browser"
STATE = HOME / "state.json"

# An active player used by upstream to prove login with a real replay.
PROBE_PLAYER = "C2J2V29GJ"


class OwnProfilePages(Pages):
    """Pages, but backed by a persistent profile this program owns.

    The base class copies a session cookie out of a browser the volunteer already uses. That
    is the one behaviour that makes a downloadable tool indistinguishable from malware, so
    this replaces it: one Chromium profile in ~/.cr-scraper, the volunteer signs in once, and
    the session lives there like it would in any browser.
    """

    def __init__(self, limiter):
        self.limiter = limiter
        self.lease_guard = None
        self.response_audit = diagnostics.ResponseAudit()
        from playwright.sync_api import sync_playwright
        PROFILE.mkdir(parents=True, exist_ok=True)
        self._pw = sync_playwright().start()
        self._browser = None
        ctx = self._pw.chromium.launch_persistent_context(
            str(PROFILE), headless=False, channel="chrome", service_workers="block",
            args=["--disable-blink-features=AutomationControlled", "--no-proxy-server"])
        self._ctx = ctx
        ctx.route("**/*", self._route)
        # Two pages, one profile. The base class keeps anon and auth apart because a 403 on
        # one triggers renew() - which re-solves the Cloudflare challenge on that page - and
        # sharing a single page made the two fight each other, so the challenge never
        # cleared. Same context means both still share the one login.
        # Keep login-page assets visible; data fetches still use upstream in-page fetch.
        anon = ctx.pages[0] if ctx.pages else ctx.new_page()
        self.anon = self.auth = anon
        # Waiting for a data-request slot keeps Playwright serving the browser.
        limiter.sleep = self._pump
        self._solve(anon, ctx)
        auth = ctx.new_page()
        self._solve(auth, ctx)
        self.auth = auth

    def _pump(self, seconds):
        """Wait while still serving the browser. A plain time.sleep would stall every
        routed request (the volunteer's sign-in, Discord, captcha) for the whole minute,
        because sync Playwright only runs route handlers inside its own calls."""
        try:
            self.auth.wait_for_timeout(seconds * 1000)
        except Exception:                                      # noqa: BLE001
            time.sleep(seconds)    # page closed or busy: still never send early

    @staticmethod
    def _route(route):
        parts = urllib.parse.urlsplit(route.request.url)
        host = parts.hostname or ""
        # Source site plus the user's interactive Discord OAuth login and captcha.
        allowed = (host == "royaleapi.com" or host.endswith(".royaleapi.com")
                   or host == "challenges.cloudflare.com"
                   or host in {"discord.com", "cdn.discordapp.com", "media.discordapp.net"}
                   or host == "hcaptcha.com" or host.endswith(".hcaptcha.com"))
        if parts.scheme == "https" and allowed and not parts.username and not parts.password:
            route.continue_()
        else:
            route.abort()

    def close(self):
        try:
            self._ctx.close()
        finally:
            self._pw.stop()

    def fetch(self, urls, auth=False):
        if self.lease_guard is not None:
            self.lease_guard.check()
        started = time.monotonic()
        for address in urls:
            path = urllib.parse.urlsplit(address).path
            print(f"    {time.strftime('%H:%M:%S')} {'replay' if path == '/data/replay' else path}",
                  flush=True)
        result = super().fetch(urls, auth)
        for url, response in zip(urls, result):
            try:
                saved = self.response_audit.record(url, response, time.monotonic() - started)
                if saved:
                    print(f"  source HTTP {response[0]}: failure response saved locally: {saved}", flush=True)
            except (OSError, ValueError, TypeError):
                print("  Could not save local source diagnostics; response validation still applies.", flush=True)
            status, _, body, retry_after = response
            if (status == 200 and urllib.parse.urlsplit(url).path == "/data/replay"
                    and "you are over your rate limit" in body.lower()):
                try:
                    payload = json.loads(body)
                except ValueError:
                    continue
                if isinstance(payload, dict) and payload.get("success") is False:
                    wait = self.limiter.blocked(retry_after_seconds(retry_after))
                    raise AccountBlocked(f"RoyaleAPI reports a replay rate limit; cooldown at least {wait:g}s")
        return result

    def renew(self, auth):
        if self.lease_guard is not None:
            self.lease_guard.check()
        return super().renew(auth)


class LeaseLost(RuntimeError):
    """Stop fetching or completing work after ownership can no longer be established."""


class LeaseHeartbeat:
    """Renew work and replay reservations independently of browser/429 waits."""

    def __init__(self, server, token, units, interval=30.0, ttl=900.0):
        self.server, self.token = local_server(server), token
        self.leases = [{"unit_id": u["unit_id"], "lease_id": u["lease_id"]} for u in units]
        self.interval, self.ttl = interval, ttl
        self.last_success = time.monotonic()
        self.reason = None
        self._stop = threading.Event()
        self._thread = None

    def check(self):
        if self.reason:
            raise LeaseLost(self.reason)
        if time.monotonic() - self.last_success >= max(0.0, self.ttl - 30.0):
            self.reason = "coordinator lease could not be renewed; work remains resumable"
            raise LeaseLost(self.reason)

    def renew_once(self):
        self.check()
        try:
            result = connection.request(self.server, "/heartbeat", {"leases": self.leases},
                                        token=self.token, timeout=10)
            if set(result.get("renewed", [])) != {lease["unit_id"] for lease in self.leases}:
                self.reason = "coordinator no longer recognizes every active lease"
            else:
                self.last_success = time.monotonic()
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403, 409):
                self.reason = "machine access was revoked or its work lease was lost"
        except (OSError, ValueError):
            # A brief network outage is not revocation; check() enforces the lease deadline.
            pass

    def _run(self):
        while not self._stop.wait(self.interval):
            try:
                self.renew_once()
                self.check()
            except LeaseLost:
                return

    def start(self):
        self._thread = threading.Thread(target=self._run, name="coordinator-heartbeat", daemon=True)
        self._thread.start()
        return self

    def close(self):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=11)


def post(server, token, path, body, retries=0):
    """POST json, directly (no proxy), retrying forever by default.

    503 means the coordinator's database was busy and nothing was written: wait and send
    the same batch again. 500 is retried a few times, then raised, so a coordinator bug
    stops the run instead of looping on one batch for ever.
    """
    server = local_server(server)
    data = json.dumps(body).encode()
    req = urllib.request.Request(f"{server.rstrip('/')}{path}", data=data,
                                 headers={"Content-Type": "application/json", "User-Agent": "cr-collector/3.0",
                                          "X-Token": token})
    delay, tries, errors = 3, 0, 0
    while True:
        if path == "/submit" and body.get("battles") and SUBMIT_PACE is not None:
            SUBMIT_PACE.acquire()
        if ACTIVE_LEASES is not None and path in ("/reserve", "/submit", "/fail"):
            ACTIVE_LEASES.check()
        try:
            with DIRECT.open(req, timeout=120) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise SystemExit("the coordinator rejected this machine's token (unapproved or revoked)")
            if e.code == 409 and path in ("/reserve", "/submit", "/fail", "/release"):
                raise LeaseLost("the coordinator refused a stale work lease") from None
            if e.code in (429, 502, 503, 504) or (e.code == 500 and errors < 4):
                errors += e.code == 500
                wait = max(delay, retry_after_seconds(e.headers.get("Retry-After")))
                print(f"  coordinator answered {e.code}; sending again in {wait:g}s", flush=True)
                time.sleep(wait)
                delay = min(delay * 2, 120)
                continue
            raise
        except Exception as exc:                              # noqa: BLE001
            tries += 1
            if retries and tries >= retries:
                raise
            print(f"  coordinator unreachable ({exc}); retrying in {delay}s", flush=True)
            time.sleep(delay)
            delay = min(delay * 2, 120)


def get(server, path, token=None):
    server = local_server(server)
    req = urllib.request.Request(f"{server.rstrip('/')}{path}",
                                 headers={"User-Agent": "cr-collector/3.0", **({"X-Token": token} if token else {})})
    with DIRECT.open(req, timeout=60) as r:
        return json.loads(r.read())


def load_state():
    try:
        return json.loads(STATE.read_text())
    except Exception:                                          # noqa: BLE001
        return {}


def save_state(s):
    HOME.mkdir(parents=True, exist_ok=True)
    temporary = STATE.with_suffix(".tmp")
    temporary.write_text(json.dumps(s, indent=1))
    temporary.replace(STATE)


class RandomInterval:
    """Space starts on one serial request stream, including retries."""

    FLOOR = SUBMIT_INTERVAL     # never closer than this, whatever the coordinator says
    DEFAULT_MAX = SUBMIT_INTERVAL

    def __init__(self, config=None):
        config = config or {}

        def seconds(key, default):
            # inf would make random.uniform return nan and acquire() never wait; a value
            # that is not a finite number falls back to the default instead.
            value = float(config.get(key, default))
            return value if math.isfinite(value) else default

        self.minimum = max(self.FLOOR, seconds("request_interval_min", self.FLOOR))
        self.maximum = max(self.minimum, seconds("request_interval_max", self.DEFAULT_MAX))
        self.next_start = 0.0
        # How to wait. None = time.sleep; the browser client swaps in a Playwright wait so
        # the collector's Chrome keeps working (sign-in, captcha) while a slot elapses.
        self.sleep = None

    def acquire(self):
        remaining = self.next_start - time.monotonic()
        while remaining > 0:
            (self.sleep or time.sleep)(remaining)
            remaining = self.next_start - time.monotonic()
        self.next_start = time.monotonic() + random.uniform(self.minimum, self.maximum)


class CollectionLimiter(RandomInterval):
    """The RoyaleAPI schedule, one serial stream per machine:
    - replay requests: SOURCE_INTERVAL between starts (a coordinator interval above it is
      honoured, random between its min and max; anything shorter is raised to it);
    - any data request: a random DATA_INTERVAL_MIN-MAX after the previous one;
    - 429 cooldowns hold both. All of it survives a restart."""

    FLOOR = SOURCE_INTERVAL
    DEFAULT_MAX = SOURCE_INTERVAL

    def __init__(self, state, config=None):
        super().__init__(config)
        self.state = state
        self.backoff = 0.0
        now, mono = time.time(), time.monotonic()
        cooldown = float(state.get("royaleapi_retry_at") or 0) - now

        # The previous run's next allowed starts, so a quick restart still waits them out.
        # Capped at one interval in case the wall clock was moved back.
        def saved(key, cap):
            return max(0.0, cooldown, min(float(state.get(key) or 0) - now, cap))

        self.next_start = mono + saved("royaleapi_next_start", DATA_INTERVAL_MAX)
        self.next_replay = mono + saved("royaleapi_next_replay", self.maximum)

    def acquire(self, replay=False):
        while True:
            target = max(self.next_start, self.next_replay) if replay else self.next_start
            remaining = target - time.monotonic()
            if remaining <= 0:
                break
            (self.sleep or time.sleep)(remaining)
        mono = time.monotonic()
        self.next_start = mono + random.uniform(DATA_INTERVAL_MIN, DATA_INTERVAL_MAX)
        if replay:
            self.next_replay = mono + random.uniform(self.minimum, self.maximum)
        wall = time.time()
        self.state["royaleapi_next_start"] = wall + (self.next_start - mono)
        self.state["royaleapi_next_replay"] = wall + (self.next_replay - mono)
        save_state(self.state)

    def acquire_for(self, address):
        """Called by the transport with the URL about to be fetched."""
        self.acquire(replay=urllib.parse.urlsplit(address).path == "/data/replay")

    def blocked(self, retry_after=0.0):
        self.backoff = min(900.0, max(60.0, self.backoff * 2))
        wait = max(self.backoff, retry_after)
        self.next_start = max(self.next_start, time.monotonic() + wait)
        self.next_replay = max(self.next_replay, time.monotonic() + wait)
        self.state["royaleapi_retry_at"] = time.time() + wait
        save_state(self.state)
        return wait

    def ok(self):
        self.backoff = 0.0


def wait_for_saved_cooldown(state):
    remaining = float(state.get("royaleapi_retry_at") or 0) - time.time()
    if remaining > 0:
        print(f"  saved rate-limit cooldown: {remaining:.0f}s remaining before opening RoyaleAPI",
              flush=True)
        while remaining > 0:
            time.sleep(min(remaining, 30.0))
            remaining = float(state["royaleapi_retry_at"]) - time.time()


class AccountBlocked(RuntimeError):
    """RoyaleAPI is refusing this session or connection, not one player: lost login,
    Cloudflare, 429s that outlast every backoff, or replays refused (success: false) again
    and again. Every next player would fail the same way, so the run stops instead."""


# Refused replays in a row (with nothing served in between) that stop the run.
REFUSED_STOP = 5
# Players in a row recorded as failed that stop the run: by then it is not the players.
FAILED_PLAYERS_STOP = 3


def account_level(e) -> bool:
    if isinstance(e, (ClearanceExpired, pipeline.ReplayRefused)):
        return True
    if isinstance(e, RateLimited) and getattr(e, "status", None) == 429:
        return True
    return isinstance(e, AuthError) and "login" in str(e)


class Refusals:
    """Counts account-level refusals in a row; a served replay resets it."""

    def __init__(self):
        self.streak, self.last = 0, None

    def hit(self, e):
        self.streak += 1
        self.last = e
        if self.streak >= REFUSED_STOP:
            raise AccountBlocked(f"{self.streak} refusals in a row, last: {e}")

    def served(self):
        self.streak = 0


REFUSALS = Refusals()


def wanted(cards, allow, block):
    cards = set(cards or ())
    if cards & set(block):
        return False
    return not allow or bool(cards & set(allow))


def ensure_login(client, pages):
    """Open the login page and wait until a real replay fetch succeeds.

    Every attempt to *detect* login was wrong in a different way: navigating to /me threw
    away what the person was typing, the session cookie is set for anonymous visitors too,
    and Cloudflare 403s the request API whether signed in or not.

    So this does not detect anything. It tries the actual work - fetching one replay, which
    is the only login-gated call - and treats success as proof. A test that IS the work
    cannot report a state the work does not have.
    """
    try:
        pages.auth.goto("https://royaleapi.com/login", wait_until="domcontentloaded",
                        timeout=60_000)
    except Exception:                                          # noqa: BLE001
        pass
    print("\n  Checking access with a real history page and replay.")
    print("  If already signed in, keep this browser open; no new login is assumed necessary.")
    print("  If the site asks you to sign in, do so in the browser window.\n",
          flush=True)

    started = time.monotonic()
    while time.monotonic() - started < 3600:
        pages.auth.wait_for_timeout(15_000)
        try:
            print(f"  access check: reading {PROBE_PLAYER}'s latest history page", flush=True)
            rows = pipeline.player_battles(client, PROBE_PLAYER, max_pages=1)
            rows = [r for r in rows if r.get("replay_tag")]
            if not rows:
                print("  access check: the probe player has no recorded replay; "
                      "continuing with queued players. Their real requests still must pass validation.",
                      flush=True)
                return True
            print("  access check: history read; fetching one replay", flush=True)
            pipeline.fetch_replay(client, rows[0])
            print("  logged in, thanks. working.\n", flush=True)
            return True
        except AccountBlocked as exc:
            raise SystemExit(f"  STOPPED: {exc}") from None
        except Exception as exc:                               # noqa: BLE001
            print(f"  access check failed: {type(exc).__name__}: {exc}", flush=True)
    return False


class CoordinatorSink:
    """Collects battles from pipeline.replays and posts them in batches.

    Every batch belongs to one active player lease. A successful batch write saves its
    raw records but never marks that player's whole history complete.
    """

    def __init__(self, server, token, name, unit, batch=25):
        self.server, self.token, self.name = server, token, name
        self.unit, self.batch = unit, batch
        self.buf, self.kept = [], 0
        self.bad_in_a_row = 0
        self.outbox = connection.ReplayOutbox(server)

    def write(self, b, stats, plays, raw=None):
        from royale import parse
        REFUSALS.served()                # a replay came back: the account is being served
        b = dict(b)
        row_html = b.pop("row_html", None)
        history = b.pop("history", None)
        if history is not None:
            # whose history page the row is on: its result label is that player's
            history = dict(history, source_player_tag=b.get("player_tag"),
                           source_url=b.get("history_url"))
        battle = {**b, **stats, "plays": plays}
        battle["cards"] = sorted(parse.base_cards(b.get("team_deck", "")))
        if self.unit.get("rating") is not None:
            battle["rating"] = self.unit["rating"]
        # The record proper: everything a replay is rebuilt from (royale/payload.py).
        battle.update({
            "record_schema": "cr-collector.record.v2",
            "request": pipeline.replay_params(b),
            "replay_response": raw,
            "history": history,
            "history_row_html": row_html,
            "requested_player_tag": b.get("player_tag"),
            "history_url": b.get("history_url"),
            "fetched_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        })
        try:
            replay_payload.build(battle)
            self.bad_in_a_row = 0
        except Exception as exc:                               # noqa: BLE001
            # Still sent: the raw pages are kept, and a parser fix can recover it later.
            self.bad_in_a_row += 1
            print(f"    {b.get('replay_tag')}: cannot build a replay yet ({exc})", flush=True)
        self.outbox.save(battle)
        self.buf.append(battle)
        if self.bad_in_a_row >= MAX_BAD_IN_A_ROW:
            self.flush()
            raise SystemExit(f"{self.bad_in_a_row} battles in a row could not be turned "
                             "into replays - RoyaleAPI's pages have probably changed. "
                             "Stopped; what was collected is saved.")
        if len(self.buf) >= self.batch:
            self.flush()
        return True

    def flush(self, unit_id=None):
        if not self.buf and unit_id is None:
            return
        res = post(self.server, self.token, "/submit",
                   {"unit_id": self.unit["unit_id"], "lease_id": self.unit["lease_id"],
                    "battles": self.buf, "complete": False})
        self.kept += res["kept"]
        if not res.get("incomplete", 0):
            self.outbox.acknowledge(self.buf)
        if self.buf:
            print(f"    sent {len(self.buf)}: kept {res['kept']}, dup {res['duplicate']}, "
                  f"filtered {res['filtered']}, incomplete {res.get('incomplete', 0)}", flush=True)
        self.buf = []
        if res.get("incomplete", 0):
            raise RuntimeError(f"coordinator rejected {res['incomplete']} incomplete replay(s); "
                               "the player remains unfinished")


def do_group(client, server, token, units, cfg, name):
    """Crawl a GROUP of players at once, the way the original scraper does.

    One player's history must be walked in order - page N+1's cursor comes from page N - so
    crawling a single player leaves every request waiting on the last. pipeline.battles
    advances every player by one page per round and fetches the round as one batch, which is
    what makes the original roughly three times faster. Doing one player at a time was the
    whole speed gap.
    """
    from royale import parse
    allow, block = cfg.get("allow") or [], cfg.get("block") or []
    tags = [u["target"].lstrip("#") for u in units]
    by_tag = {u["target"].lstrip("#"): u for u in units}
    players = {t: {"player_tag": t} for t in tags}

    # One player at a time. The group crawl (n=8 above) overlaps the page walks and should
    # be roughly three times faster, but it has never been measured end to end - the test IP
    # tripped Cloudflare before a run completed. This path is the one that has actually
    # collected battles, so it is what volunteers get until the faster one is proven.
    print(f"  crawling: {', '.join(tags)}", flush=True)

    # battles() walks every player one page per round, which is what makes it fast, but it
    # only RETURNS once the whole group is exhausted. on_done fires as each player finishes, so
    # their replays are fetched then: same overlap, progress every minute or two instead.
    # The sink was built with {"rating": None}, so no battle ever carried a rating, the
    # server read it as 0, and a min_rating filter silently rejected everything. The rating
    # belongs to the player whose history the battle came from, so it is set per player.
    sink = CoordinatorSink(server, token, name, {"rating": None},
                           batch=max(1, min(25, int(cfg.get("submit_batch", 25)))))
    # Players whose history or replays could not all be read. They are not marked done, so
    # the coordinator hands them out again after its lease runs out, without a retry cap
    # instead of the battles being silently missing.
    incomplete: dict[str, str] = {}
    deferred: dict[str, int] = {}

    def player_finished(tag, kept):
        # Never send one player's buffered records under another player's lease.
        sink.flush()
        sink.unit = by_tag.get(tag) or {"rating": None}
        rows = [b for b in kept if b.get("replay_tag")]
        if not rows:
            return
        tag_list = [b["replay_tag"] for b in rows]
        reserved, known, busy = set(), set(), set()
        for i in range(0, len(tag_list), 2000):
            requested = set(tag_list[i:i + 2000])
            result = post(server, token, "/reserve",
                          {"unit_id": sink.unit["unit_id"], "lease_id": sink.unit["lease_id"],
                           "tags": tag_list[i:i + 2000]})
            groups = [set(result[key]) for key in ("reserved", "known", "busy")]
            if (set.union(*groups) != requested
                    or any(groups[a] & groups[b] for a, b in ((0, 1), (0, 2), (1, 2)))):
                raise RuntimeError("coordinator returned an incomplete or ambiguous replay reservation")
            reserved.update(result["reserved"])
            known.update(result["known"])
            busy.update(result["busy"])
        if busy:
            deferred[tag] = len(busy)
        todo = [b for b in rows if b["replay_tag"] in reserved]
        pending = []
        for b in todo:
            cached = sink.outbox.load(pipeline.replay_params(b))
            try:
                if cached is not None:
                    replay_payload.build(cached)
            except Exception:
                cached = None
            if cached is None:
                pending.append(b)
            else:
                sink.buf.append(cached)
                if len(sink.buf) >= sink.batch:
                    sink.flush()
        todo = pending
        print(f"    {tag}: {len(rows)} battles, {len(todo)} new", flush=True)
        if not todo:
            return
        errors, gone = [], []

        def failed(b, e):
            if account_level(e):
                REFUSALS.hit(e)          # stops the run once refusals keep coming
            # Missing/expired responses are reported separately, but are not evidence of
            # a stored replay. Leave the unit resumable even after HTTP 404/410.
            if isinstance(e, AuthError) and e.status in (404, 410):
                gone.append(b)
            else:
                errors.append(str(e))
        pipeline.replays(client, todo, sink=sink, on_error=failed, slice_size=1)
        if errors:
            incomplete[tag] = f"{len(errors)} of {len(todo)} replays failed, e.g. {errors[0]}"
        if gone:
            print(f"    {tag}: {len(gone)} replays missing or expired (HTTP 404/410)",
                  flush=True)
            incomplete.setdefault(tag, f"{len(gone)} reserved replay(s) returned HTTP 404/410 without data")

    def history_failed(tag, e):
        if account_level(e):
            raise AccountBlocked(f"history page of {tag}: {e}")
        incomplete[tag] = f"history page failed: {e}"
        print(f"    {tag}: history page failed ({e})", flush=True)

    try:
        pipeline.battles(
            client, players, found_on={}, seed="", max_pages=HISTORY_PAGES_PER_PLAYER,
            keep_deck=lambda deck: wanted(parse.base_cards(deck or ""), allow, block),
            # regular 1v1 only (no 2v2, challenges, party modes), decided from the history
            # row before any replay is fetched
            reject=lambda b: parse.not_normal_1v1(b.get("history")) is not None,
            on_done=player_finished, on_error=history_failed)
    except (AccountBlocked, LeaseLost, KeyboardInterrupt, SystemExit):
        raise
    except Exception as exc:                                   # noqa: BLE001
        # anything else that broke the walk (an unrecognised page, a coordinator refusal)
        # is this player's failure: record it, keep what was already collected
        for t in tags:
            incomplete.setdefault(t, f"{type(exc).__name__}: {exc}")
    finally:
        # Keep the replays already collected, whatever happened.
        try:
            sink.flush()
        except LeaseLost:
            raise
        except Exception as exc:                               # noqa: BLE001
            for t in tags:
                incomplete.setdefault(t, f"saving replays failed: {exc}")

    # Done, or recorded as failed: either way the run moves on to the next player.
    failed_now = 0
    for u in units:
        tag = u["target"].lstrip("#")
        if tag in incomplete:
            failed_now += 1
            print(f"  {tag} recorded as failed ({incomplete[tag]}); moving on", flush=True)
            post(server, token, "/fail", {"unit_id": u["unit_id"], "lease_id": u["lease_id"],
                                          "reason": incomplete[tag]})
            continue
        if tag in deferred:
            print(f"  {tag}: {deferred[tag]} replays belong to another active collector; "
                  "returning this player to pending", flush=True)
            post(server, token, "/release", {"unit_id": u["unit_id"], "lease_id": u["lease_id"]})
            continue
        post(server, token, "/submit",
             {"unit_id": u["unit_id"], "lease_id": u["lease_id"], "battles": [], "complete": True})
    print(f"  group done: {sink.kept} new battles\n", flush=True)
    return sink.kept, failed_now


def main():
    global PINNED_SERVER, ACTIVE_LEASES, SUBMIT_PACE
    ap = argparse.ArgumentParser()
    ap.add_argument("--server", help="loopback or the exact HTTPS origin already saved with --join")
    ap.add_argument("--token", help="explicit loopback machine token (normally read from the connection file)")
    ap.add_argument("--join", help="request approval from this exact HTTPS coordinator")
    ap.add_argument("--join-only", action="store_true", help="save/request enrollment and exit without a browser")
    ap.add_argument("--connection-file", type=Path, default=connection.DEFAULT_CONNECTION)
    ap.add_argument("--machine-name", default="")
    ap.add_argument("--name", default="")
    args = ap.parse_args()
    proposed_name = args.machine_name or args.name or platform.node() or "collector"
    try:
        saved = (connection.start_join(args.join, proposed_name, args.connection_file)
                 if args.join else connection.load_connection(args.connection_file))
        if saved is not None:
            PINNED_SERVER = saved["server"]
            if args.server and connection.origin(args.server) != saved["server"]:
                raise ValueError("--server differs from the pinned connection; use a separate connection file")
            args.server = saved["server"]
            if saved.get("status") != "approved":
                if saved.get("status") in ("expired", "revoked"):
                    raise ValueError(f"machine enrollment is {saved['status']}; request approval again with --join")
                saved = connection.start_join(saved["server"], proposed_name, args.connection_file)
                print(f"  machine: {saved['name']}\n  approval code: {saved.get('code', '(pending)')}", flush=True)
                manager = ("cloud.py" if saved["server"] == "https://cr-coordinator.mingjiali129.workers.dev"
                           else "run_local.py")
                print(f"  On the owner's PC run: python coordinator/{manager} --approve {saved.get('code', '<code>')}",
                      flush=True)
                if args.join_only:
                    return
                while saved.get("status") == "pending":
                    time.sleep(5)
                    try:
                        saved = connection.poll_join(args.connection_file)
                    except (OSError, ValueError):
                        print("  approval check unavailable; saved enrollment will be retried", flush=True)
                if saved.get("status") != "approved":
                    raise ValueError(f"machine enrollment is {saved.get('status')}; restart with --join to retry")
            args.token = saved["token"]
            proposed_name = saved["name"]
        elif not args.token:
            raise ValueError("no approved machine connection; start with --join https://<your coordinator>")
        else:
            args.server = args.server or "http://127.0.0.1:8787"
            PINNED_SERVER = None
        args.server = local_server(args.server)  # refuse before the browser even opens
        if args.join_only:
            return
        startup_config = get(args.server, "/config", args.token)  # establish approval before any source requests
    except (ValueError, OSError) as exc:
        raise SystemExit(f"machine connection unavailable ({type(exc).__name__}: {exc}); "
                         "any saved enrollment is retained") from None

    state = load_state()
    name = proposed_name
    state["name"] = name
    save_state(state)

    print(f"\n  Clash Royale replay collector\n  volunteer id: {name}")
    print(f"  server: {args.server}\n  profile: {PROFILE}\n")

    wait_for_saved_cooldown(state)
    limiter = CollectionLimiter(state, startup_config)
    pages = OwnProfilePages(limiter)
    save_state(state)
    SUBMIT_PACE = RandomInterval()
    replay_pace = (f"one every {limiter.minimum:g}s" if limiter.minimum == limiter.maximum
                   else f"random {limiter.minimum:g}-{limiter.maximum:g}s apart")
    print(f"  RoyaleAPI replays: {replay_pace}, retries included; other data requests "
          f"(history pages): random {DATA_INTERVAL_MIN:g}-{DATA_INTERVAL_MAX:g}s apart; opening pages is not paced; "
          f"uploads to the coordinator: {SUBMIT_PACE.minimum:g}s apart", flush=True)
    client = Client(pages, limiter=limiter, batch=1, recover_batch=False)
    # Save each response before fetching the next; refusal streaks still stop at five.
    units = []
    try:
        if not ensure_login(client, pages):
            raise SystemExit("not logged in - restart when you are ready")
        print("  starting queued collection.\n", flush=True)

        total = state.get("collected", 0)
        failed_in_a_row = 0
        while True:
            try:
                cfg = get(args.server, "/config", args.token)
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403):
                    raise SystemExit("the coordinator rejected this machine (unapproved or revoked)") from None
                print("  coordinator settings unavailable; retrying in 5s", flush=True)
                time.sleep(5)
                continue
            except (OSError, ValueError):
                print("  coordinator settings unavailable; retrying in 5s", flush=True)
                time.sleep(5)
                continue
            units = post(args.server, args.token, "/claim",
                         {"worker": name, "n": 1})["units"]
            if not units:
                print("  no work available; checking again in 60s", flush=True)
                time.sleep(60)
                continue
            ACTIVE_LEASES = LeaseHeartbeat(args.server, args.token, units).start()
            pages.lease_guard = ACTIVE_LEASES
            try:
                kept, failed_now = do_group(client, args.server, args.token, units, cfg, name)
            except LeaseLost as exc:
                raise SystemExit(f"  STOPPED: {exc}. Unfinished players remain available to resume.") from None
            except AccountBlocked as exc:
                # Not this player's fault: back in the queue, and stop - every next player
                # would be refused the same way, and pushing on is what gets accounts banned.
                for u in units:
                    post(args.server, args.token, "/release",
                         {"unit_id": u["unit_id"], "lease_id": u["lease_id"]})
                units = []
                raise SystemExit(
                    f"\n  STOPPED: RoyaleAPI is refusing this account or connection ({exc}).\n"
                    "  Collected battles are saved and the current player is back in the queue.\n"
                    "  In the collector's Chrome window check you are logged in and a replay opens;\n"
                    "  refusal alone does not prove an account ban or establish a recovery time.\n"
                    f"  Source failure responses are kept locally in {diagnostics.ROOT}.") from None
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as exc:                           # noqa: BLE001
                # Something outside the player walk (e.g. the coordinator answered an error):
                # record these players as failed and carry on.
                failed_now = len(units)
                kept = 0
                for u in units:
                    post(args.server, args.token, "/fail",
                         {"unit_id": u["unit_id"], "lease_id": u["lease_id"],
                          "reason": f"{type(exc).__name__}: {exc}"})
                print(f"  recorded as failed ({type(exc).__name__}: {exc}); moving on", flush=True)
            finally:
                ACTIVE_LEASES.close()
                ACTIVE_LEASES = None
                pages.lease_guard = None
            units = []
            total += kept
            failed_in_a_row = failed_in_a_row + 1 if failed_now else 0
            state["collected"] = total
            save_state(state)
            print(f"  total collected by you: {total}\n", flush=True)
            if failed_in_a_row >= FAILED_PLAYERS_STOP:
                raise SystemExit(
                    f"\n  STOPPED: {failed_in_a_row} players in a row failed - that points at the\n"
                    "  connection or the site, not the players. They are recorded; see them with\n"
                    "  run_local.py --failures, and put them back with run_local.py --retry-failed.")
    except (KeyboardInterrupt, SystemExit) as stop:
        for u in units:                 # the player being collected goes straight back
            try:
                post(args.server, args.token, "/release",
                     {"unit_id": u["unit_id"], "lease_id": u["lease_id"]},
                     retries=1)
            except (Exception, SystemExit):                    # noqa: BLE001
                pass
        if isinstance(stop, SystemExit):
            raise
        print("\n  stopped. run it again any time - it picks up where it left off.")
    finally:
        try:
            pages.close()
        except Exception:                                      # noqa: BLE001
            pass


if __name__ == "__main__":
    main()
