"""An explicitly pinned coordinator and resumable, machine-owned enrollment.

No coordinator request follows redirects or uses system/environment proxies. The join
secret and eventual machine token are created and saved before the first request: a
lost approval response therefore cannot strand a machine or reveal its token twice.
"""
from __future__ import annotations

import ipaddress
import hashlib
import json
import os
import secrets
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

UPSTREAM_SERVERS = frozenset({"34.138.159.155"})
DEFAULT_CONNECTION = Path.home() / ".cr-scraper" / "connection.json"
OUTBOX_ROOT = Path.home() / ".cr-scraper" / "outbox"


class ReplayOutbox:
    """Original evidence survives a killed collector or an unavailable coordinator."""
    def __init__(self, server):
        self.folder = OUTBOX_ROOT / hashlib.sha256(origin(server).encode()).hexdigest()[:24]

    def path(self, params):
        key = json.dumps(params, sort_keys=True, separators=(",", ":"))
        return self.folder / (hashlib.sha256(key.encode()).hexdigest() + ".json")

    def save(self, record):
        self.folder.mkdir(parents=True, exist_ok=True)
        path = self.path(record["request"])
        temp = path.with_suffix(".tmp")
        fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd,"w",encoding="utf-8") as file:
            json.dump(record,file,ensure_ascii=False)
            file.flush()
            os.fsync(file.fileno())
        temp.replace(path)

    def load(self, params):
        path = self.path(params)
        if not path.exists():
            return None
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
            return record if record.get("request") == params else None
        except (OSError,ValueError):
            return None

    def acknowledge(self, records):
        for record in records:
            if self.load(record["request"]) == record:
                self.path(record["request"]).unlink(missing_ok=True)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


DIRECT = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())


def origin(value: str) -> str:
    """Validate an explicit join destination; it must be a bare HTTPS origin or local HTTP."""
    try:
        parts = urllib.parse.urlsplit(value)
        host = parts.hostname or ""
        port = parts.port
        if (not host or parts.username is not None or parts.password is not None
                or parts.path not in ("", "/") or parts.query or parts.fragment
                or "\\" in value or any(c.isspace() for c in value)):
            raise ValueError("use a bare coordinator origin, without a path or credentials")
        if host.rstrip(".") in UPSTREAM_SERVERS:
            raise ValueError("the upstream collection server is not an allowed destination")
        try:
            local = ipaddress.ip_address(host).is_loopback
        except ValueError:
            local = host == "localhost"
        if parts.scheme != "https" and not (parts.scheme == "http" and local):
            raise ValueError("public coordinators require HTTPS; HTTP is only allowed on loopback")
        authority = f"[{host}]" if ":" in host else host
        default = 443 if parts.scheme == "https" else 80
        if port is not None and port != default:
            authority += f":{port}"
        return f"{parts.scheme}://{authority}"
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid coordinator address: {exc}") from None


def allowed_server(value: str, pinned: str | None = None) -> str:
    normalized = origin(value)
    parts = urllib.parse.urlsplit(normalized)
    try:
        local = ipaddress.ip_address(parts.hostname).is_loopback
    except ValueError:
        local = parts.hostname == "localhost"
    if (parts.scheme == "http" and local) or (pinned and normalized == origin(pinned)):
        return normalized
    raise ValueError("this HTTPS coordinator has not been pinned with --join")


def request(server, path, body=None, *, token=None, timeout=20):
    """One bounded request. Callers decide retries; enrollment explicitly selects its origin."""
    server = origin(server)
    if not path.startswith("/") or path.startswith("//") or "?" in path or "#" in path:
        raise ValueError("invalid coordinator endpoint")
    headers = {"Content-Type": "application/json", "User-Agent": "cr-collector/3.0"}
    if token:
        headers["X-Token"] = token
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(server + path, data=data, headers=headers)
    with DIRECT.open(req, timeout=timeout) as response:
        return json.loads(response.read())


def load_connection(path=DEFAULT_CONNECTION):
    path = Path(path)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not data.get("token") or not data.get("secret"):
        raise ValueError("invalid machine connection file; it was not overwritten")
    data["server"] = origin(data["server"])
    return data


def save_connection(data, path=DEFAULT_CONNECTION):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=2)
            file.flush()
            os.fsync(file.fileno())
        temporary.replace(path)
        path.chmod(0o600)
    finally:
        if temporary.exists():
            temporary.unlink()


def start_join(server, name, path=DEFAULT_CONNECTION):
    server = origin(server)
    data = load_connection(path)
    if data is not None and data["server"] != server:
        raise ValueError("connection file is pinned to another coordinator; use a separate --connection-file")
    if data is None or data.get("status") == "expired":
        data = {"version": 1, "server": server, "name": name,
                "secret": secrets.token_urlsafe(32), "token": secrets.token_urlsafe(32),
                "status": "pending"}
        save_connection(data, path)
    if data.get("status") == "revoked":
        raise ValueError("this machine was revoked; ask the coordinator owner before enrolling again")
    if data.get("status") == "approved":
        return data
    result = request(server, "/join/start", {"name": data["name"], "secret": data["secret"],
                                            "token": data["token"]})
    data.update({k: result[k] for k in ("code", "status", "machine_id") if k in result})
    save_connection(data, path)
    return data


def poll_join(path=DEFAULT_CONNECTION):
    data = load_connection(path)
    if data is None:
        raise ValueError("no pending machine enrollment")
    try:
        result = request(data["server"], "/join/poll", {"secret": data["secret"]})
    except urllib.error.HTTPError as exc:
        if exc.code not in (404, 410):
            raise
        # Expired requests may already have been pruned. Do not poll a nonexistent
        # secret forever: persist the terminal status so --join can safely renew it.
        result = {"status": "expired"}
    data.update({k: result[k] for k in ("status", "machine_id") if k in result})
    save_connection(data, path)
    return data
