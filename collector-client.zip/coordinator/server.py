"""Local work coordinator for this machine's own replay collection.

This copy runs on 127.0.0.1 only, next to the client, and keeps everything in one
SQLite file of your own (default data/work.db). It never talks to any other
collection server. The coordinator owns:

  * the set of replay tags already collected, so the same battle is never fetched twice
  * the deck filter and the other collection settings
  * the leases, so a crashed client does not strand its players
  * the battles themselves, in the order they were written (`battle.seq`), each with the
    raw pages it came from: the /data/replay answer and the battle's history row.
    Every export is built from those raw pages (royale/payload.py), never from a summary.

Standard library only - sqlite3 and http.server - so running it needs no install.

    python coordinator/run_local.py            (starts this and the client together)
    python coordinator/server.py --db data/work.db --token SECRET --port 8787
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import hmac
import ipaddress
import json
import re
import secrets
import sqlite3
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from royale import parse                                       # noqa: E402
from royale import payload as replay_payload                   # noqa: E402

# What a battle record must carry to be stored: the replay answer and the history row
# are the only sources of levels, tower troops, tower HP, data-i and the end time.
RAW_FIELDS = ("replay_tag", "request", "replay_response", "history")

JOIN_TTL = 900
MAX_PENDING_JOINS = 32
LEASE_SECONDS = 900
IDLE_GAP = 600           # a gap over this is treated as "the machine was off", not working          # a volunteer that goes quiet for 15 minutes loses its unit

SCHEMA = """
CREATE TABLE IF NOT EXISTS machine (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL DEFAULT 'active',
  created_at REAL NOT NULL,
  last_seen REAL
);
CREATE TABLE IF NOT EXISTS join_request (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  secret_hash TEXT NOT NULL UNIQUE,
  token_hash TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL DEFAULT 'pending',
  created_at REAL NOT NULL,
  expires_at REAL NOT NULL,
  machine_id TEXT
);
CREATE TABLE IF NOT EXISTS replay_reservation (
  replay_tag TEXT PRIMARY KEY,
  worker TEXT NOT NULL,
  unit_id INTEGER NOT NULL,
  lease_id TEXT NOT NULL,
  expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS unit (
  id          INTEGER PRIMARY KEY,
  kind        TEXT NOT NULL,              -- 'player' or 'deck'
  target      TEXT NOT NULL,              -- player tag, or deck signature
  rating      INTEGER,                    -- known rating, so rating filters work per player
  state       TEXT NOT NULL DEFAULT 'open',   -- open | leased | done
  leased_by   TEXT,
  leased_at   REAL,
  attempts    INTEGER NOT NULL DEFAULT 0,
  UNIQUE(kind, target)
);
CREATE INDEX IF NOT EXISTS unit_open ON unit(state, attempts);

-- The dedup ledger for successfully validated replay records.
CREATE TABLE IF NOT EXISTS seen (
  replay_tag  TEXT PRIMARY KEY,
  worker      TEXT,
  at          REAL
);

-- One row per collected battle. A quarantined row may be repaired in place. `seq` is the write order:
-- AUTOINCREMENT never reuses a number, so seq order is insertion order for good and
-- the exporter can cut its parts by it (export_hf.py). `record` is the gzip of the
-- record's JSON, raw pages included. `problem` is NULL when royale/payload.py can
-- build a replay from it, otherwise the reason it cannot.
CREATE TABLE IF NOT EXISTS battle (
  seq         INTEGER PRIMARY KEY AUTOINCREMENT,
  replay_tag  TEXT NOT NULL UNIQUE,
  record      BLOB NOT NULL,
  worker      TEXT,
  at          REAL,
  problem     TEXT
);

-- Operator-controlled filter. Empty allow list means "allow everything".
CREATE TABLE IF NOT EXISTS deck_rule (
  card        TEXT PRIMARY KEY,
  rule        TEXT NOT NULL               -- 'allow' or 'block'
);

-- Operator knobs, adjustable while everything is running. Clients read them at the start
-- of every unit, so a change reaches every volunteer within a minute or two.
CREATE TABLE IF NOT EXISTS setting (
  key         TEXT PRIMARY KEY,
  value       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS worker (
  name        TEXT PRIMARY KEY,
  first_seen  REAL,
  last_seen   REAL,
  submitted   INTEGER NOT NULL DEFAULT 0,
  rejected    INTEGER NOT NULL DEFAULT 0,
  -- Time actually spent working, not wall-clock since first contact. A volunteer who runs
  -- an hour a night for a week would otherwise look a hundred times slower than they are.
  active_secs REAL NOT NULL DEFAULT 0,
  units_done  INTEGER NOT NULL DEFAULT 0
);
"""


class APIError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def secret_hash(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class Store:
    def __init__(self, path):
        # RLock, not Lock: submit() holds it and then calls wanted() -> deck_rules(),
        # which takes it again. A plain Lock deadlocks there.
        self.lock = threading.RLock()
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        # WAL: an export or import reading the database does not block the coordinator's
        # writes (nor they its reads). The timeout covers the short waits that remain.
        self.db = sqlite3.connect(path, timeout=60, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        cols = {r[1] for r in self.db.execute("PRAGMA table_info(battle)")}
        if cols and "seq" not in cols:
            # A database from the upstream build: its battle table keeps parsed rows only
            # (no raw pages) and loses write order on INSERT OR REPLACE. Keep it aside
            # rather than mixing two formats in one table.
            self.db.execute("ALTER TABLE battle RENAME TO battle_upstream_format")
            self.db.commit()
        self.db.executescript(SCHEMA)
        # CREATE TABLE IF NOT EXISTS leaves an existing table alone, so a database made by
        # an older build keeps its old columns. Add anything missing rather than making the
        # operator rebuild and lose the dedup ledger.
        have = {r[1] for r in self.db.execute("PRAGMA table_info(unit)")}
        if "rating" not in have:
            self.db.execute("ALTER TABLE unit ADD COLUMN rating INTEGER")
        if "lease_id" not in have:
            self.db.execute("ALTER TABLE unit ADD COLUMN lease_id TEXT")
        if "failure" not in have:
            # why a player ended in state 'failed' (the run recorded it and moved on)
            self.db.execute("ALTER TABLE unit ADD COLUMN failure TEXT")
            self.db.execute("ALTER TABLE unit ADD COLUMN failed_at REAL")
        havew = {r[1] for r in self.db.execute("PRAGMA table_info(worker)")}
        for col, decl in (("active_secs", "REAL NOT NULL DEFAULT 0"),
                          ("units_done", "INTEGER NOT NULL DEFAULT 0")):
            if col not in havew:
                self.db.execute(f"ALTER TABLE worker ADD COLUMN {col} {decl}")
        # Earlier builds marked quarantined raw records seen, preventing a valid
        # refetch. Keep their raw evidence, but make them eligible for recovery.
        self.db.execute("DELETE FROM seen WHERE replay_tag IN "
                        "(SELECT replay_tag FROM battle WHERE problem IS NOT NULL)")
        self.db.commit()
        self._join_windows = {}

    def add_units(self, kind, targets, ratings=None):
        ratings = ratings or {}
        with self.lock:
            self.db.executemany(
                "INSERT OR IGNORE INTO unit(kind, target, rating) VALUES (?, ?, ?)",
                [(kind, t, ratings.get(t)) for t in targets])
            self.db.commit()
            return self.db.total_changes

    def settings(self):
        with self.lock:
            rows = self.db.execute("SELECT key, value FROM setting").fetchall()
        return {k: v for k, v in rows}

    def set_setting(self, key, value):
        with self.lock:
            if value in ("", None):
                self.db.execute("DELETE FROM setting WHERE key=?", (key,))
            else:
                self.db.execute("INSERT OR REPLACE INTO setting(key,value) VALUES (?,?)",
                                (key, str(value)))
            self.db.commit()

    def claim(self, worker, n=1):
        """Hand out open units, reclaiming any whose lease has expired."""
        cutoff = time.time() - LEASE_SECONDS
        with self.lock:
            self._assert_worker_active(worker)
            self.db.execute(
                "UPDATE unit SET state='open', leased_by=NULL, lease_id=NULL "
                "WHERE state='leased' AND leased_at < ?", (cutoff,))
            self.db.execute("DELETE FROM replay_reservation WHERE NOT EXISTS "
                            "(SELECT 1 FROM unit WHERE unit.id=replay_reservation.unit_id "
                            "AND unit.state='leased' AND unit.lease_id=replay_reservation.lease_id "
                            "AND unit.leased_by=replay_reservation.worker)")
            minr = self.settings().get("min_rating")
            if minr:
                rows = self.db.execute(
                    "SELECT id, kind, target, rating FROM unit WHERE state='open' "
                    "AND (rating IS NULL OR rating >= ?) "
                    "ORDER BY attempts, id LIMIT ?", (int(minr), n)).fetchall()
            else:
                rows = self.db.execute(
                    "SELECT id, kind, target, rating FROM unit "
                    "WHERE state='open' ORDER BY attempts, id LIMIT ?",
                    (n,)).fetchall()
            now = time.time()
            units = []
            for uid, _, _, _ in rows:
                lease_id = secrets.token_urlsafe(24)
                self.db.execute(
                    "UPDATE unit SET state='leased', leased_by=?, leased_at=?, lease_id=?, "
                    "attempts=attempts+1 WHERE id=?", (worker, now, lease_id, uid))
                units.append(lease_id)
            self.db.execute(
                "INSERT INTO worker(name, first_seen, last_seen) VALUES (?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET last_seen=excluded.last_seen",
                (worker, now, now))
            self.db.commit()
        return [{"unit_id": r[0], "kind": r[1], "target": r[2], "rating": r[3],
                 "lease_id": lease_id}
                for r, lease_id in zip(rows, units)]

    def _assert_worker_active(self, worker):
        # Trusted local Store callers may use legacy names. HTTP worker identities
        # always come from the authenticated machine table.
        if worker.startswith("m_"):
            row = self.db.execute("SELECT state FROM machine WHERE id=?", (worker,)).fetchone()
            if not row or row[0] != "active":
                raise APIError(401, "machine revoked or unknown")

    def _lease(self, worker, unit_id, lease_id):
        self._assert_worker_active(worker)
        row = self.db.execute(
            "SELECT state, leased_by, lease_id, leased_at FROM unit WHERE id=?",
            (unit_id,)).fetchone()
        if (not row or row[0] != "leased" or row[1] != worker
                or not lease_id or row[2] != lease_id
                or row[3] is None or row[3] < time.time() - LEASE_SECONDS):
            raise APIError(409, "lease expired or owned by another worker")
        return row[3] + LEASE_SECONDS

    def heartbeat(self, worker, leases):
        with self.lock:
            for unit in leases:
                self._lease(worker, unit["unit_id"], unit["lease_id"])
            now = time.time()
            for unit in leases:
                self.db.execute("UPDATE unit SET leased_at=? WHERE id=?",
                                (now, unit["unit_id"]))
                self.db.execute("UPDATE replay_reservation SET expires_at=? "
                                "WHERE unit_id=? AND lease_id=? AND worker=?",
                                (now + LEASE_SECONDS, unit["unit_id"],
                                 unit["lease_id"], worker))
            prev = self.db.execute("SELECT last_seen FROM worker WHERE name=?", (worker,)).fetchone()
            gap = now - prev[0] if prev and prev[0] else 0.0
            active = gap if 0 < gap <= IDLE_GAP else 0.0
            self.db.execute("UPDATE worker SET last_seen=?,active_secs=active_secs+? WHERE name=?",
                            (now, active, worker))
            self.db.commit()
            return {"renewed": [u["unit_id"] for u in leases]}

    def reserve(self, worker, unit_id, lease_id, tags):
        """Atomically claim downloads, including battles found under both opponents."""
        with self.lock:
            lease_deadline = self._lease(worker, unit_id, lease_id)
            now = time.time()
            self.db.execute("DELETE FROM replay_reservation WHERE expires_at < ?", (now,))
            known = self.known(tags)
            reserved, busy = [], []
            for tag in dict.fromkeys(tags):
                if tag in known:
                    continue
                row = self.db.execute("SELECT worker, unit_id, lease_id FROM replay_reservation "
                                      "WHERE replay_tag=?", (tag,)).fetchone()
                if row and row != (worker, unit_id, lease_id):
                    busy.append(tag)
                    continue
                self.db.execute("INSERT OR REPLACE INTO replay_reservation "
                                "(replay_tag, worker, unit_id, lease_id, expires_at) VALUES (?,?,?,?,?)",
                                (tag, worker, unit_id, lease_id, lease_deadline))
                reserved.append(tag)
            self.db.commit()
            return {"reserved": reserved, "known": sorted(known), "busy": busy}

    def join_limit(self, action):
        # Global limits are intentional: X-Forwarded-For is not trusted, and all
        # Cloudflare requests arrive through a local process. This also bounds memory.
        limit = 12 if action == "start" else 120
        with self.lock:
            now = time.time()
            since, count = self._join_windows.get(action, (now, 0))
            if now - since >= 60:
                since, count = now, 0
            if count >= limit:
                raise APIError(429, "too many enrollment requests; retry in 60 seconds")
            self._join_windows[action] = (since, count + 1)

    @staticmethod
    def _secret(value):
        if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", value):
            raise APIError(400, "secret and token must be independent random URL-safe strings")
        return secret_hash(value)

    def join_start(self, name, secret, token):
        sh, th = self._secret(secret), self._secret(token)
        if hmac.compare_digest(sh, th):
            raise APIError(400, "enrollment secret and machine token must differ")
        if not isinstance(name, str) or not 1 <= len(name) <= 64 or not name.isprintable():
            raise APIError(400, "machine name must be 1 to 64 printable characters")
        with self.lock:
            now = time.time()
            row = self.db.execute("SELECT code, state, expires_at, token_hash FROM join_request "
                                  "WHERE secret_hash=?", (sh,)).fetchone()
            if row:
                if not hmac.compare_digest(row[3], th):
                    raise APIError(409, "enrollment secret already used")
                state = "expired" if row[1] == "pending" and row[2] < now else row[1]
                return {"code": row[0], "status": state, "expires_at": row[2]}
            # Expired rows are removed; approved entries are retained for a lost
            # poll response. Only hashes are ever stored or sent to administration.
            self.db.execute("DELETE FROM join_request WHERE state='pending' AND expires_at < ?", (now,))
            if self.db.execute("SELECT COUNT(*) FROM join_request WHERE state='pending'").fetchone()[0] >= MAX_PENDING_JOINS:
                self.db.commit()
                raise APIError(429, "enrollment queue is full")
            if (self.db.execute("SELECT 1 FROM machine WHERE token_hash=?", (th,)).fetchone()
                    or self.db.execute("SELECT 1 FROM join_request WHERE token_hash=?", (th,)).fetchone()):
                self.db.commit()
                raise APIError(409, "machine token already used")
            alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            while True:
                code = "".join(secrets.choice(alphabet) for _ in range(6))
                if not self.db.execute("SELECT 1 FROM join_request WHERE code=?", (code,)).fetchone():
                    break
            self.db.execute("INSERT INTO join_request "
                            "(code,name,secret_hash,token_hash,created_at,expires_at) VALUES (?,?,?,?,?,?)",
                            (code, name, sh, th, now, now + JOIN_TTL))
            self.db.commit()
            return {"code": code, "status": "pending", "expires_at": now + JOIN_TTL}

    def join_poll(self, secret):
        sh = self._secret(secret)
        with self.lock:
            row = self.db.execute("SELECT state, machine_id, expires_at FROM join_request "
                                  "WHERE secret_hash=?", (sh,)).fetchone()
            if not row:
                raise APIError(404, "enrollment request not found or expired")
            state, machine_id, expires = row
            if state == "pending" and expires < time.time():
                state = "expired"
            if machine_id:
                machine = self.db.execute("SELECT state FROM machine WHERE id=?", (machine_id,)).fetchone()
                if not machine or machine[0] != "active":
                    state = "revoked"
            return {"status": state, "machine_id": machine_id, "expires_at": expires}

    def approve(self, code):
        with self.lock:
            row = self.db.execute("SELECT name, token_hash, state, expires_at, machine_id "
                                  "FROM join_request WHERE code=?", (str(code).upper(),)).fetchone()
            if not row:
                raise APIError(404, "enrollment code not found")
            name, th, state, expires, machine_id = row
            if state == "approved":
                return {"ok": True, "machine_id": machine_id, "name": name}
            if expires < time.time():
                raise APIError(410, "enrollment request expired")
            machine_id = "m_" + secrets.token_hex(12)
            now = time.time()
            self.db.execute("INSERT INTO machine(id,name,token_hash,created_at) VALUES (?,?,?,?)",
                            (machine_id, name, th, now))
            self.db.execute("UPDATE join_request SET state='approved', machine_id=? WHERE code=?",
                            (machine_id, str(code).upper()))
            self.db.commit()
            return {"ok": True, "machine_id": machine_id, "name": name}

    def authenticate(self, token):
        with self.lock:
            row = self.db.execute("SELECT id FROM machine WHERE token_hash=? AND state='active'",
                                  (secret_hash(token),)).fetchone()
            if not row:
                return None
            self.db.execute("UPDATE machine SET last_seen=? WHERE id=?", (time.time(), row[0]))
            self.db.commit()
            return row[0]

    def machines(self):
        with self.lock:
            rows = self.db.execute("SELECT m.id,m.name,m.state,m.created_at,m.last_seen,"
                                   "COALESCE(w.submitted,0),COALESCE(w.units_done,0) "
                                   "FROM machine m LEFT JOIN worker w ON w.name=m.id "
                                   "ORDER BY m.created_at").fetchall()
            pending = self.db.execute("SELECT code,name,created_at,expires_at FROM join_request "
                                      "WHERE state='pending' AND expires_at>=? ORDER BY created_at",
                                      (time.time(),)).fetchall()
            return {"machines": [dict(zip(("machine_id", "name", "state", "created_at", "last_seen",
                                            "battles", "players_done"), r)) for r in rows],
                    "pending": [dict(zip(("code", "name", "created_at", "expires_at"), r)) for r in pending]}

    def revoke(self, machine_id):
        with self.lock:
            changed = self.db.execute("UPDATE machine SET state='revoked' WHERE id=?", (machine_id,)).rowcount
            if not changed:
                raise APIError(404, "machine not found")
            self.db.execute("UPDATE unit SET state='open', leased_by=NULL, lease_id=NULL "
                            "WHERE state='leased' AND leased_by=?", (machine_id,))
            self.db.execute("DELETE FROM replay_reservation WHERE worker=?", (machine_id,))
            self.db.commit()
            return {"ok": True, "machine_id": machine_id}

    def known(self, tags):
        """Which of these replay tags have already been collected."""
        with self.lock:
            out = set()
            for i in range(0, len(tags), 500):
                chunk = tags[i:i + 500]
                q = ",".join("?" * len(chunk))
                out.update(r[0] for r in self.db.execute(
                    f"SELECT replay_tag FROM battle WHERE problem IS NULL "
                    f"AND replay_tag IN ({q})", chunk))
            return out

    def deck_rules(self):
        with self.lock:
            rows = self.db.execute("SELECT card, rule FROM deck_rule").fetchall()
        allow = {c for c, r in rows if r == "allow"}
        block = {c for c, r in rows if r == "block"}
        return allow, block

    def wanted(self, battle):
        """Every operator filter, in one place. Returns None to keep, or a reason to drop.

        `submit` is the authority - a client that ignores the rules, or is running an old
        copy of them, still cannot put unwanted battles in the dataset.
        """
        if battle.get("history") is not None:
            why = parse.not_normal_1v1(battle["history"])
            if why:
                return why
        st = self.settings()
        allow, block = self.deck_rules()

        cards = set(battle.get("cards") or ())
        if cards & block:
            return "blocked card"
        if allow and not (cards & allow):
            return "no allowed card"

        since = st.get("since_timestamp")
        if since:
            try:
                if int(battle.get("battle_timestamp") or 0) < int(since):
                    return "too old"
            except (TypeError, ValueError):
                pass

        minr = st.get("min_rating")
        if minr:
            try:
                if int(battle.get("rating") or 0) < int(minr):
                    return "rating too low"
            except (TypeError, ValueError):
                pass

        minp = st.get("min_plays")
        if minp:
            # Top-ladder matches where nobody deploys teach nothing and waste a conversion
            # slot, so they are dropped here rather than discovered by the engine later.
            if len(battle.get("plays") or ()) < int(minp):
                return "too few plays"

        types = st.get("battle_types")
        if types:
            ok = {t.strip() for t in types.split(",") if t.strip()}
            if (battle.get("battle_type") or "") not in ok:
                return "wrong battle type"
        return None

    def insert_record(self, record, worker, at):
        """Store one battle record. 'kept', 'duplicate' or 'incomplete'.

        Valid records are immutable. A valid refetch can repair a quarantined record
        without changing its seq; another invalid response preserves its first raw
        evidence. The caller holds the lock and commits.
        """
        tag = record.get("replay_tag")
        if not isinstance(tag, str) or not tag:
            return "incomplete"
        if any(record.get(k) in (None, "", {}) for k in RAW_FIELDS):
            # No raw pages, nothing to rebuild a replay from: refuse rather than keep a
            # battle the export cannot use. Not marked seen, so it is fetched again.
            return "incomplete"
        existing = self.db.execute("SELECT problem FROM battle WHERE replay_tag=?",
                                   (tag,)).fetchone()
        if existing is not None and existing[0] is None:
            return "duplicate"
        try:
            replay_payload.build(record)
            problem = None
        except replay_payload.PayloadError as e:
            problem = str(e)[:500]
        except Exception as e:                                 # noqa: BLE001
            problem = f"{type(e).__name__}: {e}"[:500]
        blob = gzip.compress(json.dumps(record, ensure_ascii=False).encode("utf-8"), 6)
        if existing is None:
            self.db.execute("INSERT INTO battle(replay_tag, record, worker, at, problem) "
                            "VALUES (?,?,?,?,?)", (tag, blob, worker, at, problem))
        elif problem is None:
            self.db.execute("UPDATE battle SET record=?, worker=?, at=?, problem=NULL "
                            "WHERE replay_tag=?", (blob, worker, at, tag))
        if problem is not None:
            self.db.execute("DELETE FROM seen WHERE replay_tag=?", (tag,))
            return "incomplete"
        self.db.execute("INSERT OR REPLACE INTO seen(replay_tag, worker, at) VALUES (?,?,?)",
                        (tag, worker, at))
        return "kept"

    def submit(self, worker, unit_id, battles, lease_id=None, complete=None):
        """All of a batch or none of it: any error rolls the batch back, so the client can
        send the same batch again and get true counts."""
        with self.lock:
            try:
                if lease_id is not None:
                    self._lease(worker, unit_id, lease_id)
                    known = self.known([b.get("replay_tag") for b in battles if isinstance(b, dict)])
                    for battle in battles:
                        tag = battle.get("replay_tag") if isinstance(battle, dict) else None
                        if not tag or tag in known:
                            continue
                        reservation = self.db.execute(
                            "SELECT worker,unit_id,lease_id,expires_at FROM replay_reservation WHERE replay_tag=?",
                            (tag,)).fetchone()
                        if (not reservation or reservation[:3] != (worker, unit_id, lease_id)
                                or reservation[3] < time.time()):
                            raise APIError(409, "replay is not reserved by this lease")
                # Trusted local imports retain their old Store API; workers must
                # explicitly finish, so flushing a partial batch cannot complete a player.
                finish = unit_id if lease_id is None and (complete is None or complete is True) else None
                resolved = set()
                result = self._submit(worker, finish, battles, resolved)
                if lease_id is not None:
                    self.db.executemany(
                        "DELETE FROM replay_reservation WHERE replay_tag=? AND worker=? "
                        "AND unit_id=? AND lease_id=?",
                        [(tag, worker, unit_id, lease_id) for tag in resolved])
                    if complete and not result["incomplete"]:
                        unresolved = self.db.execute("SELECT 1 FROM replay_reservation "
                                                     "WHERE unit_id=? AND lease_id=? LIMIT 1",
                                                     (unit_id, lease_id)).fetchone()
                        if unresolved:
                            raise APIError(422, "unresolved replays remain; refetch, fail or release the player")
                        self.db.execute("UPDATE unit SET state='done' WHERE id=?", (unit_id,))
                        self.db.execute("UPDATE worker SET units_done=units_done+1 WHERE name=?", (worker,))
                self.db.commit()
                return result
            except BaseException:
                self.db.rollback()
                raise

    def _submit(self, worker, unit_id, battles, resolved=None):
        resolved = resolved if resolved is not None else set()
        kept = dup = filtered = incomplete = 0
        now = time.time()
        with self.lock:
            for b in battles:
                tag = (b or {}).get("replay_tag")
                if not isinstance(tag, str) or not tag:
                    incomplete += 1
                    continue
                if self.db.execute("SELECT 1 FROM battle WHERE replay_tag=? AND problem IS NULL",
                                   (tag,)).fetchone():
                    dup += 1
                    resolved.add(tag)
                    continue
                # Invalid source data is incomplete, never an intentional filter.
                # In particular a broken history row must not pass as a non-1v1 game.
                try:
                    replay_payload.build(b)
                    valid = True
                except Exception:
                    valid = False
                if valid and self.wanted(b) is not None:
                    filtered += 1
                    resolved.add(tag)
                    # Deliberately NOT marked as seen. Marking filtered battles saves a
                    # refetch, but it also means a wrong or later-relaxed filter loses them
                    # permanently - which is exactly what a rating bug did here once.
                    continue
                outcome = self.insert_record(b, worker, now)
                if outcome == "kept":
                    kept += 1
                    resolved.add(tag)
                elif outcome == "duplicate":
                    dup += 1
                    resolved.add(tag)
                else:
                    incomplete += 1
            if unit_id is not None and not incomplete:
                self.db.execute("UPDATE unit SET state='done' WHERE id=?", (unit_id,))
                self.db.execute(
                    "UPDATE worker SET units_done=units_done+1 WHERE name=?", (worker,))
            # A gap longer than IDLE_GAP means the machine was off or asleep; anything
            # shorter counts as time spent collecting.
            prev = self.db.execute("SELECT last_seen FROM worker WHERE name=?",
                                   (worker,)).fetchone()
            gap = now - prev[0] if prev and prev[0] else 0.0
            add = gap if 0 < gap <= IDLE_GAP else 0.0
            self.db.execute(
                "UPDATE worker SET submitted=submitted+?, last_seen=?, "
                "active_secs=active_secs+? WHERE name=?", (kept, now, add, worker))
        return {"kept": kept, "duplicate": dup, "filtered": filtered, "incomplete": incomplete}

    def workers(self):
        """Per-device totals and rate, so the operator can see who is collecting what."""
        with self.lock:
            rows = self.db.execute(
                "SELECT name, submitted, units_done, active_secs, first_seen, last_seen "
                "FROM worker ORDER BY submitted DESC").fetchall()
        out = []
        for name, sub, units, active, first, last in rows:
            hours = (active or 0) / 3600.0
            out.append({
                "device": name,
                "battles": sub,
                "players_done": units,
                "active_hours": round(hours, 2),
                "battles_per_hour": round(sub / hours, 1) if hours > 0.01 else None,
                "first_seen": first,
                "last_seen": last,
            })
        return out

    def fail(self, unit_id, reason, worker=None, lease_id=None):
        """A player that could not be collected: recorded with the reason and set aside
        ('failed'), so the run moves on to the next player. Not handed out again until
        retry_failed() puts it back in the queue."""
        with self.lock:
            if worker is not None:
                self._lease(worker, unit_id, lease_id)
            self.db.execute("DELETE FROM replay_reservation WHERE unit_id=?", (unit_id,))
            self.db.execute("UPDATE unit SET state='failed', leased_by=NULL, lease_id=NULL, failure=?, failed_at=? "
                            "WHERE id=? AND state='leased'", (str(reason)[:1000], time.time(), unit_id))
            self.db.commit()

    def release(self, unit_id, worker=None, lease_id=None):
        """Back to the queue as it was: the run stopped for a reason that was not this
        player's (lost login, withdrawn replay access)."""
        with self.lock:
            if worker is not None:
                self._lease(worker, unit_id, lease_id)
            self.db.execute("DELETE FROM replay_reservation WHERE unit_id=?", (unit_id,))
            self.db.execute("UPDATE unit SET state='open', leased_by=NULL, lease_id=NULL, attempts=MAX(attempts-1, 0) "
                            "WHERE id=? AND state='leased'", (unit_id,))
            self.db.commit()

    def retry_failed(self):
        with self.lock:
            n = self.db.execute("UPDATE unit SET state='open', leased_by=NULL WHERE state='failed'").rowcount
            self.db.commit()
            return n

    def failures(self, limit=50):
        with self.lock:
            return [{"player": t, "reason": r, "at": a} for t, r, a in self.db.execute(
                "SELECT target, failure, failed_at FROM unit WHERE state='failed' "
                "ORDER BY failed_at DESC LIMIT ?", (limit,))]

    def stats(self):
        with self.lock:
            row = lambda q: self.db.execute(q).fetchone()[0]
            return {
                "protocol_version": 2,
                "units_open": row("SELECT COUNT(*) FROM unit WHERE state='open'"),
                "units_leased": row("SELECT COUNT(*) FROM unit WHERE state='leased'"),
                "units_done": row("SELECT COUNT(*) FROM unit WHERE state='done'"),
                "units_failed": row("SELECT COUNT(*) FROM unit WHERE state='failed'"),
                "battles": row("SELECT COUNT(*) FROM battle"),
                "battles_with_problem": row("SELECT COUNT(*) FROM battle WHERE problem IS NOT NULL"),
                "seen": row("SELECT COUNT(*) FROM seen"),
                "workers": row("SELECT COUNT(*) FROM worker"),
            }


def make_handler(store, token):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def setup(self):
            super().setup()
            self.connection.settimeout(20)

        def log_message(self, *a):                  # quiet; the stats endpoint is the log
            pass

        def _send(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.close_connection = True
            if code == 429:
                self.send_header("Retry-After", "60")
            self.end_headers()
            self.wfile.write(body)

        def _auth(self):
            supplied = self.headers.get("X-Token") or ""
            self.admin = hmac.compare_digest(supplied, token)
            self.worker = None
            if self.admin:
                return
            if supplied and len(supplied) <= 256:
                self.worker = store.authenticate(supplied)
            if not self.worker:
                raise APIError(401, "bad token or revoked machine")

        def _admin(self):
            if not self.admin:
                raise APIError(403, "administrator token required")

        def _body(self, limit=64 * 1024 * 1024):
            if self.headers.get("Transfer-Encoding"):
                raise APIError(400, "Transfer-Encoding is not supported")
            n = int(self.headers.get("Content-Length") or 0)
            if not 0 <= n <= limit:
                raise APIError(413, "payload too large")
            body = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(body, dict):
                raise APIError(400, "body must be a JSON object")
            return body

        def _error(self, exc):
            with store.lock:
                store.db.rollback()
            if isinstance(exc, APIError):
                return self._send(exc.status, {"error": str(exc)})
            if isinstance(exc, (ValueError, TypeError, KeyError)):
                return self._send(400, {"error": "invalid request body"})
            if isinstance(exc, sqlite3.OperationalError):
                return self._send(503, {"error": "database temporarily unavailable"})
            return self._send(500, {"error": "internal coordinator error"})

        def do_GET(self):
            try:
                self._auth()
                return self._get()
            except Exception as exc:
                return self._error(exc)

        def _get(self):
            if self.path == "/stats":
                return self._send(200, store.stats())
            if self.path == "/workers":
                self._admin()
                return self._send(200, {"workers": store.workers()})
            if self.path == "/machines":
                self._admin()
                return self._send(200, store.machines())
            if self.path == "/config":
                # Clients fetch this before working, so the operator's card rules are applied
                # BEFORE a replay is fetched rather than after it is submitted. Changing the
                # rules here changes what every volunteer collects, with nothing to reinstall.
                allow, block = store.deck_rules()
                cfg = dict(store.settings())
                cfg["allow"] = sorted(allow)
                cfg["block"] = sorted(block)
                return self._send(200, cfg)
            self._send(404, {"error": "not found"})

        def do_POST(self):
            try:
                if self.path in ("/join/start", "/join/poll"):
                    store.join_limit(self.path.rsplit("/", 1)[-1])
                    body = self._body(4096)
                    if self.path == "/join/start":
                        return self._send(200, store.join_start(body.get("name"), body.get("secret"), body.get("token")))
                    return self._send(200, store.join_poll(body.get("secret")))
                self._auth()
                body = self._body()
                return self._post(body)
            except Exception as exc:                          # noqa: BLE001
                return self._error(exc)

        def _post(self, body):
            worker = str(body.get("worker") or "local-admin")[:64] if self.admin else self.worker

            if self.path == "/approve":
                self._admin()
                return self._send(200, store.approve(body["code"]))
            if self.path == "/machines":
                self._admin()
                return self._send(200, store.machines())
            if self.path == "/revoke":
                self._admin()
                return self._send(200, store.revoke(body["machine_id"]))

            if self.path == "/heartbeat":
                leases = body.get("leases")
                if (not isinstance(leases, list) or not 1 <= len(leases) <= 20
                        or any(not isinstance(u, dict) or not isinstance(u.get("unit_id"), int)
                               or not isinstance(u.get("lease_id"), str) for u in leases)):
                    raise APIError(400, "leases must contain 1 to 20 unit_id and lease_id pairs")
                return self._send(200, store.heartbeat(worker, leases))

            if self.path == "/reserve":
                tags = body.get("tags")
                if not isinstance(tags, list) or len(tags) > 5000 or any(not isinstance(t, str) or not 1 <= len(t) <= 512 for t in tags):
                    raise APIError(400, "tags must be a list of at most 5000 replay tags")
                unit, lease = self._unit_lease(body)
                return self._send(200, store.reserve(worker, unit, lease, tags))

            if self.path == "/claim":
                n = max(1, min(int(body.get("n") or 1), 20))
                return self._send(200, {"units": store.claim(worker, n)})

            if self.path == "/known":
                tags = [t for t in (body.get("tags") or []) if isinstance(t, str)][:5000]
                return self._send(200, {"known": sorted(store.known(tags))})

            if self.path == "/queue":
                self._admin()
                # Operator-only in practice: it needs the token, same as everything else.
                rows = body.get("players") or []
                if not isinstance(rows, list) or len(rows) > 20000:
                    return self._send(400, {"error": "players must be a list under 20000"})
                tags, ratings = [], {}
                for r in rows:
                    t = (r or {}).get("tag") if isinstance(r, dict) else r
                    if not isinstance(t, str) or not t:
                        continue
                    t = t.lstrip("#").upper()
                    tags.append(t)
                    if isinstance(r, dict) and r.get("rating") is not None:
                        try:
                            ratings[t] = int(r["rating"])
                        except (TypeError, ValueError):
                            pass
                total = lambda s: (s["units_open"] + s["units_done"] + s["units_leased"]
                                   + s["units_failed"])
                before = total(store.stats())
                store.add_units("player", tags, ratings)
                after = total(store.stats())
                return self._send(200, {"added": after - before, "seen_in_request": len(tags)})

            if self.path == "/submit":
                battles = body.get("battles") or []
                if not isinstance(battles, list) or len(battles) > 5000 or any(not isinstance(b, dict) for b in battles):
                    return self._send(400, {"error": "battles must be a list under 5000"})
                if self.admin and not body.get("lease_id"):
                    return self._send(200, store.submit(worker, body.get("unit_id"), battles))
                unit, lease = self._unit_lease(body)
                complete = body.get("complete", False)
                if not isinstance(complete, bool):
                    raise APIError(400, "complete must be a boolean")
                return self._send(200, store.submit(worker, unit, battles, lease, complete))

            if self.path == "/fail":
                if self.admin and not body.get("lease_id"):
                    store.fail(int(body["unit_id"]), body.get("reason") or "unknown")
                else:
                    unit, lease = self._unit_lease(body)
                    store.fail(unit, body.get("reason") or "unknown", worker, lease)
                return self._send(200, {"ok": True})

            if self.path == "/release":
                if self.admin and not body.get("lease_id"):
                    store.release(int(body["unit_id"]))
                else:
                    unit, lease = self._unit_lease(body)
                    store.release(unit, worker, lease)
                return self._send(200, {"ok": True})

            if self.path == "/retry_failed":
                self._admin()
                return self._send(200, {"reopened": store.retry_failed()})

            if self.path == "/failures":
                self._admin()
                return self._send(200, {"failures": store.failures(int(body.get("limit") or 50))})

            self._send(404, {"error": "not found"})

        def _unit_lease(self, body):
            unit, lease = body.get("unit_id"), body.get("lease_id")
            if not isinstance(unit, int) or isinstance(unit, bool) or not isinstance(lease, str) or not lease:
                raise APIError(400, "unit_id and lease_id are required")
            return unit, lease
    return Handler


class CoordinatorHTTPServer(ThreadingHTTPServer):
    """Bound simultaneous connections as the loopback server can face a tunnel."""
    daemon_threads = True

    def __init__(self, *args, **kwargs):
        self._connections = threading.BoundedSemaphore(32)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        if not self._connections.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._connections.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._connections.release()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/work.db")
    auth = ap.add_mutually_exclusive_group(required=True)
    auth.add_argument("--token", help="administrator secret (prefer --token-file)")
    auth.add_argument("--token-file", help="read administrator secret from a local file")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--host", default="127.0.0.1",
                    help="loopback only (127.0.0.1 or ::1): this coordinator serves this machine")
    ap.add_argument("--add-players", default="", help="file of player tags, one per line")
    ap.add_argument("--allow", default="", help="comma-separated cards to collect")
    ap.add_argument("--block", default="", help="comma-separated cards to never collect")
    ap.add_argument("--stats", action="store_true", help="print stats and exit")
    ap.add_argument("--since", default="", help="only battles on/after this date, YYYY-MM-DD")
    ap.add_argument("--min-rating", default="", help="skip players below this rating")
    ap.add_argument("--min-plays", default="",
                    help="drop battles with fewer card plays than this - use 4 or so to "
                         "throw away the empty top-ladder matches where nobody deploys")
    ap.add_argument("--battle-types", default="",
                    help="comma-separated battle_type values to keep; empty keeps all")
    ap.add_argument("--show", action="store_true", help="print the current filters and exit")
    ap.add_argument("--rates", action="store_true",
                    help="print per-device collection rates and exit")
    args = ap.parse_args()
    if args.token_file:
        args.token = Path(args.token_file).read_text(encoding="utf-8").strip()
    if not args.token:
        raise SystemExit("administrator token must not be empty")
    try:
        loopback = ipaddress.ip_address(args.host).is_loopback
    except ValueError:
        loopback = args.host == "localhost"
    if not loopback:
        raise SystemExit(f"--host {args.host}: this coordinator only listens on 127.0.0.1 / ::1")

    store = Store(args.db)

    for spec, rule in ((args.allow, "allow"), (args.block, "block")):
        cards = [c.strip() for c in spec.split(",") if c.strip()]
        if cards:
            with store.lock:
                store.db.executemany(
                    "INSERT OR REPLACE INTO deck_rule(card, rule) VALUES (?,?)",
                    [(c, rule) for c in cards])
                store.db.commit()
            print(f"{rule}: {', '.join(cards)}")

    import datetime as _dt
    if args.since:
        ts = int(_dt.datetime.strptime(args.since, "%Y-%m-%d").timestamp())
        store.set_setting("since_timestamp", ts)
        print(f"since: {args.since} ({ts})")
    for key, val in (("min_rating", args.min_rating), ("min_plays", args.min_plays),
                     ("battle_types", args.battle_types)):
        if val:
            store.set_setting(key, val)
            print(f"{key}: {val}")

    if args.rates:
        import datetime as _d
        rows = store.workers()
        if not rows:
            print("no devices have collected anything yet")
            return
        print(f"{'device':32s} {'battles':>8s} {'players':>8s} {'hours':>7s} {'per hour':>9s}"
              f"  last seen")
        for w in rows:
            seen = _d.datetime.fromtimestamp(w["last_seen"]).strftime("%m-%d %H:%M") \
                if w["last_seen"] else "-"
            rate = f"{w['battles_per_hour']:.0f}" if w["battles_per_hour"] else "-"
            print(f"{w['device'][:32]:32s} {w['battles']:8d} {w['players_done']:8d} "
                  f"{w['active_hours']:7.2f} {rate:>9s}  {seen}")
        tot = sum(w["battles"] for w in rows)
        hrs = sum(w["active_hours"] for w in rows)
        print(f"\n{tot} battles from {len(rows)} devices over {hrs:.1f} device-hours"
              + (f" - {tot/hrs:.0f}/hour combined" if hrs > 0.01 else ""))
        return

    if args.show:
        st = dict(store.settings())
        a, b = store.deck_rules()
        if "since_timestamp" in st:
            st["since_readable"] = _dt.datetime.fromtimestamp(
                int(st["since_timestamp"])).strftime("%Y-%m-%d")
        st["allow"] = sorted(a) or "(everything)"
        st["block"] = sorted(b) or "(nothing)"
        print(json.dumps(st, indent=1))
        return

    if args.add_players:
        tags = [t.strip() for t in open(args.add_players) if t.strip()]
        store.add_units("player", tags)
        print(f"queued {len(tags)} player units")

    if args.stats:
        print(json.dumps(store.stats(), indent=1))
        return

    srv = CoordinatorHTTPServer((args.host, args.port), make_handler(store, args.token))
    print(f"coordinator on {args.host}:{args.port}  db={args.db}")
    print(json.dumps(store.stats()))
    srv.serve_forever()


if __name__ == "__main__":
    main()
