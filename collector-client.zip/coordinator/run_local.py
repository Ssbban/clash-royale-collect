"""Run the local coordinator and collectors; approve remote machines on this PC.

    start-scraping.bat --no-client                 run the central coordinator
    start-scraping.bat --join https://YOUR-HOST     join from another machine
    python coordinator/run_local.py --approve CODE
    python coordinator/run_local.py --machines

Admin credentials stay on loopback. Each collector has a revocable machine credential.
"""
from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from coordinator import connection

DATA = ROOT / "data"
TOKEN_FILE = DATA / "coordinator.token"
HUB_FILE = DATA / "hub.json"


def token() -> str:
    DATA.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(TOKEN_FILE), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(fd, "w", encoding="ascii") as file:
            file.write(secrets.token_urlsafe(32))
    value = TOKEN_FILE.read_text(encoding="ascii").strip()
    if not value:
        raise ValueError("empty coordinator token file")
    return value


def local_origin(url):
    normalized = connection.origin(url)
    parts = urllib.parse.urlsplit(normalized)
    try:
        local = ipaddress.ip_address(parts.hostname).is_loopback
    except ValueError:
        local = parts.hostname == "localhost"
    if parts.scheme != "http" or not local:
        raise ValueError("administration is restricted to the local HTTP coordinator")
    return normalized


def stats(url: str, tok: str | None = None) -> dict | None:
    url = local_origin(url)
    try:
        return connection.request(url, "/stats", token=tok, timeout=3)
    except (OSError, ValueError):
        return None


def call(url: str, tok: str, path: str, body: dict) -> dict:
    return connection.request(local_origin(url), path, body, token=tok)


def queue(url: str, tok: str, path: Path) -> dict:
    tags = [t.strip().lstrip("#").upper() for t in path.read_text(encoding="utf-8").splitlines()
            if t.strip() and not t.lstrip().startswith("//")]
    return call(url, tok, "/queue", {"players": tags})


def read_hub():
    if not HUB_FILE.exists():
        return {}
    result = json.loads(HUB_FILE.read_text(encoding="utf-8"))
    if not isinstance(result, dict):
        raise ValueError("invalid data/hub.json")
    return result


def configure_hub(args):
    config = read_hub()
    if args.public_url:
        config["public_url"] = connection.origin(args.public_url)
    if config.get("public_url"):
        address = connection.origin(config["public_url"])
        if not address.startswith("https://"):
            raise ValueError("--public-url must use HTTPS")
        config["public_url"] = address
    if args.tunnel_token_file:
        path = args.tunnel_token_file.resolve(strict=True)
        if not path.is_file():
            raise ValueError("--tunnel-token-file must name a file")
        config["tunnel_token_file"] = str(path)
    if args.cloudflared:
        found = shutil.which(args.cloudflared)
        if not found:
            raise ValueError("cloudflared executable not found")
        config["cloudflared"] = found
    if args.public_url or args.tunnel_token_file or args.cloudflared:
        DATA.mkdir(parents=True, exist_ok=True)
        temp = HUB_FILE.with_suffix(".tmp")
        temp.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
        temp.replace(HUB_FILE)
    return config


def spawn_logged(command, logfile):
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    with open(logfile, "a", encoding="utf-8") as log:
        return subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                cwd=ROOT, creationflags=flags)


def stop_child(process):
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def start_tunnel(config):
    path = config.get("tunnel_token_file")
    if not path:
        return None  # An independently managed tunnel is also supported.
    if not config.get("public_url"):
        raise ValueError("configure --public-url before starting a named tunnel")
    if not Path(path).is_file():
        raise ValueError("saved tunnel token file is missing")
    binary = (config.get("cloudflared") or shutil.which("cloudflared")
              or str(DATA / "bin" / "cloudflared.exe"))
    if not shutil.which(binary):
        raise ValueError("install official cloudflared, then set --cloudflared PATH")
    return spawn_logged([binary, "tunnel", "--no-autoupdate", "run", "--token-file", path],
                        DATA / "cloudflared.log")


def local_connection_path(address):
    # A new explicit origin receives a fresh token. Existing credentials never migrate.
    suffix = hashlib.sha256(address.encode()).hexdigest()[:16]
    return DATA / f"local-machine-{suffix}.json"


def local_machine(address, local_url, admin, path, name):
    """The admin secret goes only to local_url, never to the public HTTPS entry."""
    joined = connection.start_join(address, name, path)
    if joined["status"] == "pending":
        call(local_url, admin, "/approve", {"code": joined["code"]})
        joined = connection.poll_join(path)
    if joined["status"] != "approved":
        raise ValueError(f"local machine enrollment is {joined['status']}")
    return joined


def parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=str(DATA / "work.db"))
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--add-players", type=Path)
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--no-client", action="store_true", help="keep coordinator/tunnel running without a collector")
    ap.add_argument("--failures", action="store_true")
    ap.add_argument("--retry-failed", action="store_true")
    ap.add_argument("--approve", metavar="CODE")
    ap.add_argument("--machines", action="store_true")
    ap.add_argument("--revoke", metavar="MACHINE_ID")
    ap.add_argument("--public-url", metavar="HTTPS_ORIGIN", help="save the shared HTTPS entry")
    ap.add_argument("--tunnel-token-file", type=Path, help="save named Tunnel token file path")
    ap.add_argument("--cloudflared", help="official cloudflared executable path")
    ap.add_argument("--join", metavar="HTTPS_ORIGIN", help="collector only: request approval from a hub")
    ap.add_argument("--join-only", action="store_true", help="enroll without opening RoyaleAPI")
    ap.add_argument("--machine-name", default=socket.gethostname())
    ap.add_argument("--connection-file", type=Path)
    return ap


def main() -> int:
    ap = parser()
    args = ap.parse_args()
    if args.join:
        if any((args.no_client, args.public_url, args.tunnel_token_file, args.cloudflared,
                args.approve, args.machines, args.revoke, args.add_players, args.stats,
                args.failures, args.retry_failed)):
            ap.error("--join is collector-only; administration runs on the coordinator PC")
        command = [sys.executable, str(ROOT / "coordinator" / "client.py"), "--join", args.join,
                   "--machine-name", args.machine_name]
        if args.connection_file:
            command += ["--connection-file", str(args.connection_file)]
        if args.join_only:
            command += ["--join-only"]
        return subprocess.call(command, cwd=ROOT)
    server = tunnel = worker = None
    try:
        config = configure_hub(args)
        tok = token()
        url = f"http://127.0.0.1:{args.port}"
        current = stats(url, tok)
        if current is None:
            server = spawn_logged([sys.executable, str(ROOT / "coordinator" / "server.py"),
                                   "--db", args.db, "--token-file", str(TOKEN_FILE),
                                   "--port", str(args.port), "--host", "127.0.0.1"],
                                  DATA / "coordinator.log")
            for _ in range(50):
                current = stats(url, tok)
                if current is not None:
                    break
                if server.poll() is not None:
                    raise RuntimeError(f"coordinator exited; see {DATA / 'coordinator.log'}")
                time.sleep(0.2)
            else:
                raise RuntimeError("coordinator did not become ready; no collector was started")
        if current.get("protocol_version") != 2:
            raise RuntimeError("an old coordinator is running; stop its launcher and restart with this version")
        if args.add_players:
            print("queued:", queue(url, tok, args.add_players))
        if args.retry_failed:
            print("back in the queue:", call(url, tok, "/retry_failed", {})["reopened"])
        if args.approve:
            print("approved:", json.dumps(call(url, tok, "/approve", {"code": args.approve})))
        if args.revoke:
            print("revoked:", json.dumps(call(url, tok, "/revoke", {"machine_id": args.revoke})))
        if args.machines:
            print(json.dumps(call(url, tok, "/machines", {}), indent=2, ensure_ascii=False))
        if args.failures:
            for failure in call(url, tok, "/failures", {"limit": 200})["failures"]:
                when = time.strftime("%m-%d %H:%M", time.localtime(failure["at"])) if failure["at"] else "?"
                print(f"  {when}  {failure['player']}: {failure['reason']}")
        if any((args.stats, args.failures, args.approve, args.revoke, args.machines)):
            print("coordinator:", json.dumps(stats(url, tok)))
            return 0
        tunnel = start_tunnel(config)
        address = config.get("public_url", url)
        print(f"shared collector entry: {address}" if config.get("public_url")
              else "Local mode: no fixed HTTPS entry configured yet.")
        if not args.no_client:
            path = args.connection_file or local_connection_path(address)
            for attempt in range(12):
                try:
                    local_machine(address, url, tok, path, args.machine_name)
                    break
                except OSError:
                    if not tunnel or attempt == 11 or tunnel.poll() is not None:
                        raise
                    time.sleep(2)
            command = [sys.executable, str(ROOT / "coordinator" / "client.py"),
                       "--connection-file", str(path)]
            if args.join_only:
                command += ["--join-only"]
            worker = subprocess.Popen(command, cwd=ROOT)
            if args.join_only:
                return worker.wait()
        print(f"coordinator running on {url}; Ctrl+C stops this launcher and its own services")
        while True:
            if server is not None and server.poll() is not None:
                raise RuntimeError("coordinator exited; unfinished leases will recover on restart")
            if tunnel is not None and tunnel.poll() is not None:
                raise RuntimeError(f"Cloudflare tunnel exited; see {DATA / 'cloudflared.log'}")
            if worker is not None and worker.poll() is not None:
                print(f"local collector stopped (exit {worker.returncode}); coordinator remains available")
                worker = None
            time.sleep(1)
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"Unable to run: {exc}", file=sys.stderr)
        return 1
    finally:
        stop_child(worker)
        stop_child(tunnel)
        stop_child(server)


if __name__ == "__main__":
    sys.exit(main())
