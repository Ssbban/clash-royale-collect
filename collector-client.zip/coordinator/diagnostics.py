"""Local-only source response evidence. Never collect cookies or request headers."""
from collections import deque
import datetime as dt
import json
import os
from pathlib import Path
import secrets
from urllib.parse import urlsplit, parse_qs

ROOT = Path.home() / ".cr-scraper" / "diagnostics"


class ResponseAudit:
    def __init__(self):
        self.recent = deque(maxlen=30)

    def record(self, url, response, elapsed):
        from royale.transport import refusal
        status, final, body, retry_after = response
        path = urlsplit(url).path
        try:
            data = json.loads(body)
        except (ValueError, TypeError):
            data = None
        replay_ok = isinstance(data, dict) and data.get("success") is True
        event = dict(at=dt.datetime.now(dt.timezone.utc).isoformat(), path=path,
                     status=status, elapsed_seconds=round(elapsed, 3),
                     final_path=urlsplit(final).path, retry_after=str(retry_after)[:80],
                     replay_tag=parse_qs(urlsplit(url).query).get("tag", [None])[0],
                     success=data.get("success") if isinstance(data, dict) and
                             type(data.get("success")) is bool else None)
        self.recent.append(event)
        if status == 200 and not refusal(body) and (path != "/data/replay" or replay_ok):
            return None
        ROOT.mkdir(parents=True, exist_ok=True)
        target = ROOT / (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") +
                         "-" + secrets.token_hex(4) + ".json")
        fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(dict(response=event, recent_responses=list(self.recent),
                           response_body=body), file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        return target
