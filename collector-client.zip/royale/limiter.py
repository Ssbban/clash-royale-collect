"""Self-tuning request rate.

RoyaleAPI's 429 threshold is not published and moves, so nothing here guesses
it: the limiter probes upward while requests succeed and halves on every 429,
which settles just under whatever the real ceiling is right now. Plain AIMD --
the same control loop TCP uses, for the same reason.

One instance is shared by every worker thread; `acquire` is the only blocking
call and it hands out evenly spaced slots, so 12 threads at 8 req/s behave like
8 req/s and not like 12 bursts.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field


@dataclass
class Limiter:
    rate: float = 2.0        # requests per second, right now
    floor: float = 0.5       # never crawl slower than this
    ceiling: float = 8.0     # never probe past this -- tunable, kept low by default
    step: float = 0.25       # additive increase per successful round, after a 429
    growth: float = 1.03     # multiplicative increase per success, before any 429
    penalty: float = 2.0     # minimum pause after a 429
    backoff_factor: float = field(default=1.0, kw_only=True)
    max_penalty: float = field(default=900.0, kw_only=True)

    hits: int = 0            # 429s seen
    peak: float = 0.0        # fastest rate that held
    sent: int = 0

    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    _next: float = field(default=0.0, repr=False)
    _blocked_until: float = field(default=0.0, init=False, repr=False)
    _consecutive: int = field(default=0, init=False, repr=False)
    _backoff: float = field(default=0.0, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.backoff_factor < 1:
            raise ValueError("backoff_factor must be at least 1")
        if self.max_penalty < 0:
            raise ValueError("max_penalty must not be negative")

    def acquire(self) -> None:
        """Block until this thread's slot in the schedule comes up."""
        with self._lock:
            now = time.monotonic()
            self._next = max(now, self._next) + 1.0 / self.rate
            deadline = self._next
            self.sent += 1
        while True:
            with self._lock:
                # A concurrent 429 may extend the hold while this slot is asleep.
                deadline = max(deadline, self._blocked_until)
                wait = deadline - time.monotonic()
            if wait <= 0:
                return
            time.sleep(wait)

    def ok(self) -> None:
        """A request came back clean: go faster."""
        with self._lock:
            self._consecutive = 0
            self._backoff = 0.0
            if self.hits:
                # Congestion avoidance: step/rate, not step, so one full
                # increment lands per round of requests instead of per request.
                self.rate = min(self.ceiling, self.rate + self.step / self.rate)
            else:
                # Slow start. No 429 has ever been seen, so the ceiling is still
                # unknown and creeping up would waste the whole run finding it.
                self.rate = min(self.ceiling, self.rate * self.growth)
            self.peak = max(self.peak, self.rate)

    def blocked(self, retry_after: float = 0.0) -> float:
        """A 429: halve the rate and return the chosen cooldown in seconds.

        Consecutive failures optionally grow the fallback pause. A server-provided
        Retry-After is always respected, even when longer than max_penalty.
        """
        with self._lock:
            self.hits += 1
            self.rate = max(self.floor, self.rate / 2)
            self._consecutive += 1
            fallback = self.penalty if self._consecutive == 1 else self._backoff * self.backoff_factor
            self._backoff = min(max(self.penalty, self.max_penalty), fallback)
            now = time.monotonic()
            self._blocked_until = max(self._blocked_until, now + max(retry_after, self._backoff))
            self._next = max(self._next, self._blocked_until)
            return self._blocked_until - now

    def __str__(self) -> str:
        return f"{self.rate:.1f}/s peak {self.peak:.1f}/s · {self.hits} x 429"
