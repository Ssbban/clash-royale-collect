"""A collected battle's raw pages -> one replay payload in the IL_Replay format.

The payload is schema `royaleapi-battle-actions.v1`, the per-replay JSON that the
VanguardX101/IL_Replay dataset stores in `payload_json` and that FirstLight_CR's
`prepare_collected_replay` reads: both decks with levels and forms, both tower
troops with levels, the six final tower hit points, crowns and result, every
card play (tick, side, card, point) and hero/champion ability, the replay's end
time, and RoyaleAPI's elixir table. Nothing here touches the network: it reads
the record the collector stored, so a later fix to this file can be re-run over
everything already collected.

A record (what the coordinator keeps per battle) needs:
    replay_tag          the replay asked for
    request             the /data/replay parameters (tag, team_tags, opponent_tags,
                        team_crowns, opponent_crowns, referrer_path)
    replay_response     the /data/replay answer as text: {"success": ..., "html": ...}
    history             the battle's /battles/history row, parsed (parse.history_row)
    fetched_at          when the replay was fetched (ISO 8601, UTC)
    requested_player_tag  whose history the row came from (optional)

Coordinates follow IL_Replay exactly (checked on its rows for both data-i values):
RoyaleAPI's data-x/data-y are turned into the team's own seat frame, team at the
bottom: data-i 0 -> (x, 32000 - y), data-i 1 -> (18000 - x, y).
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict, deque
from html.parser import HTMLParser

SCHEMA = "royaleapi-battle-actions.v1"
COLLECTION_SCHEMA = "royaleapi-replay-collection.v1"
TICKS_PER_SECOND = 20
FORM_SUFFIX = re.compile(r"-(ev\d+|hero)$")

# Cards whose ability RoyaleAPI shows as a separate timeline event (data-ability 1),
# besides the hero forms (-hero). Same list as the game data's champions.
CHAMPIONS = frozenset({"archer-queen", "boss-bandit", "goblinstein", "golden-knight",
                       "little-prince", "mighty-miner", "monk", "skeleton-king", "terry"})
TABLE_ROWS = ("total", "troop", "building", "spell", "ability")


class PayloadError(ValueError):
    """The record cannot be turned into a trustworthy replay; the reason says why."""


def base_card(key: str) -> str:
    return FORM_SUFFIX.sub("", key or "")


def _classes(attrs) -> set:
    return set((attrs.get("class") or "").split())


class ReplayHTML(HTMLParser):
    """The map markers, timeline cards, clock labels and both elixir tables."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.replay_id = None
        self.markers = []      # map markers: one per play or ability, data-x/y/c/t/s/i
        self.timeline = []     # timeline cards: data-s blue/red, data-card, data-t, data-ability
        self.clock = []        # clock labels: {'attrs', 'text'}
        self.tables = []       # replay_elixir_table: {title: [cells]}
        self.text = []
        self._clock = None
        self._table = self._row = self._cell = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        c = _classes(a)
        if "battle_replay" in c:
            self.replay_id = a.get("data-tag")
        if "marker" in c and "data-x" in a and "data-t" in a:
            self.markers.append(a)
        elif "marker" in c and "left:" in (a.get("style") or "") and "data-t" not in a:
            self._clock = {"attrs": a, "text": ""}
        if tag == "img" and "replay_card" in c and "data-t" in a:
            self.timeline.append(a)
        if tag == "table" and "replay_elixir_table" in c:
            self._table = {}
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag == "td" and self._row is not None:
            self._cell = ""

    def handle_data(self, data):
        self.text.append(data)
        if self._clock is not None:
            self._clock["text"] += data
        if self._cell is not None:
            self._cell += data

    def handle_endtag(self, tag):
        if tag == "div" and self._clock is not None:
            self.clock.append(self._clock)
            self._clock = None
        elif tag == "td" and self._row is not None and self._cell is not None:
            self._row.append(self._cell.strip())
            self._cell = None
        elif tag == "tr" and self._table is not None and self._row:
            self._table[self._row[0]] = self._row[1:]
            self._row = None
        elif tag == "table" and self._table is not None:
            self.tables.append(self._table)
            self._table = None


def _int(value):
    if value is None or str(value) in ("None", "null", ""):
        return None
    if not re.fullmatch(r"-?\d+", str(value).strip()):
        raise PayloadError(f"not an integer: {value!r}")
    return int(value)


def _number(text):
    m = re.search(r"-?\d+(?:\.\d+)?", str(text if text is not None else "").replace(",", ""))
    if not m:
        return None
    return float(m.group(0)) if "." in m.group(0) else int(m.group(0))


def _left(attrs):
    m = re.search(r"left:\s*(-?[\d.]+)px", attrs.get("style") or "")
    return float(m[1]) if m else None


def _clock_scale(p: ReplayHTML):
    """(end tick, end label) from the clock labels; also proves data-t is 20 per second."""
    clock = []
    for entry in p.clock:
        if "end_time" in _classes(entry["attrs"]):
            continue  # its seconds are rounded; it only marks the end
        m = re.search(r"(\d+):(\d{2})", entry["text"])
        px = _left(entry["attrs"])
        if m and px is not None:
            clock.append((int(m[1]) * 60 + int(m[2]), px))
    if len(clock) < 2:
        raise PayloadError("fewer than two clock labels; tick scale unverifiable")
    first, last = min(clock), max(clock)
    px_per_second = (last[1] - first[1]) / (last[0] - first[0])
    ratios = []
    for a in p.timeline:
        tick, px = _int(a.get("data-t")), _left(a)
        if tick and px is not None:
            ratios.append((px - first[1]) / tick)
    if not ratios or max(ratios) - min(ratios) > 1e-8:
        raise PayloadError("timeline cards are not evenly spaced in ticks")
    tps = px_per_second / ratios[0]
    if not math.isclose(tps, TICKS_PER_SECOND, abs_tol=1e-8):
        raise PayloadError(f"timeline runs at {tps} ticks per second, not 20")
    end = next((e for e in p.clock if "end_time" in _classes(e["attrs"])), None)
    if end is None or _left(end["attrs"]) is None:
        raise PayloadError("no end-of-battle label on the timeline")
    end_tick = round((_left(end["attrs"]) - first[1]) / ratios[0])
    return end_tick, re.sub(r"\s+", " ", end["text"]).strip()


def _check_side_marker(markers: list, data_i: int) -> None:
    """data-i decides which half each side played from, so a wrong one mirrors every point.
    Cross-check it with the coordinate snap: the low-y side's drops sit on tile centres
    (y % 1000 == 500) while the high-y side's are partly one unit lower (..499). data-i 1
    means the team is the low-y side. When the snap is clear and says otherwise, refuse."""
    snap = {"t": Counter(), "o": Counter()}
    for a in markers:
        s, y = a.get("data-s"), _int(a.get("data-y"))
        if s in snap and y is not None:
            snap[s][y % 1000] += 1
    share = {s: (c[499] / (c[499] + c[500]) if c[499] + c[500] else None) for s, c in snap.items()}
    if share["t"] is None or share["o"] is None:
        return
    if share["t"] <= 0.02 and share["o"] >= 0.1:
        team_low = True
    elif share["o"] <= 0.02 and share["t"] >= 0.1:
        team_low = False
    else:
        return  # the snap does not say; data-i stands
    if team_low != (data_i == 1):
        raise PayloadError(f"data-i {data_i} puts the team on the {'high' if data_i == 0 else 'low'}-y "
                           f"side, the coordinate snap on the {'low' if team_low else 'high'}-y side")


def coordinates(x: int, y: int, data_i: int) -> dict:
    """RoyaleAPI data-x/data-y -> IL_Replay's coordinate block (team's seat frame)."""
    nx, ny = (x, 32000 - y) if data_i == 0 else (18000 - x, y)
    gx, gy = nx // 1000, ny // 1000
    return {
        "arena_label_from_blue": {"column": chr(ord("A") + gx), "row": gy + 1},
        "display_royaleapi_units": {"x": nx, "y": 32000 - ny},
        "grid_cell_floor": {"x": gx, "y": gy},
        "inside_18x32_arena": 0 <= nx < 18000 and 0 <= ny < 32000,
        # as IL_Replay: true when the team was True Red (data-i 1) and x was turned round
        "inversion_applied": data_i == 1,
        "native_world_units": {"x": nx, "y": ny},
        "raw_royaleapi_units": {"x": x, "y": y},
        "subcell_offset_from_floor_center": {"x": round((nx - gx * 1000 - 500) / 1000, 3),
                                             "y": round((ny - gy * 1000 - 500) / 1000, 3)},
    }


def _elixir_table(table: dict) -> dict:
    out = {}
    for title, cells in table.items():
        key = title.strip().lower()
        if key == "leaked":
            out["leaked"] = _number(cells[0]) if cells else None
        elif key in TABLE_ROWS:
            count = _number(cells[0]) if cells else None
            elixir = _number(cells[1]) if len(cells) > 1 else None
            if type(count) is not int or count < 0:
                raise PayloadError(f"elixir table {key}: count is not a nonnegative integer ({count!r})")
            if elixir is None or not math.isfinite(elixir) or elixir < 0:
                raise PayloadError(f"elixir table {key}: elixir missing or invalid ({elixir!r})")
            out[key] = [count, int(elixir) if float(elixir).is_integer() else elixir]
    if any(key not in out for key in TABLE_ROWS):
        raise PayloadError("elixir table is missing count rows")
    if out.get("leaked") is None or not math.isfinite(out["leaked"]) or out["leaked"] < 0:
        raise PayloadError("elixir table leaked amount missing or invalid")
    return out


def _stat(side: dict, name: str):
    """A history-row stat. Its text repeats the label ('4-Card Cycle 8.0'), so the
    label is cut off before the number is read."""
    for s in side.get("stats") or ():
        if s.get("name") == name:
            text = str(s.get("value") or "")
            if text.startswith(name):
                text = text[len(name):]
            v = _number(text)
            return None if v is None else float(v)
    return None


def _player(side: dict, tag: str) -> dict:
    """One side of the history row -> IL_Replay's player block."""
    names = {p.get("tag"): p.get("name") for p in side.get("players") or ()}
    cards = side.get("cards") or []
    if len(cards) != 8:
        raise PayloadError(f"player {tag}: {len(cards)} deck cards in the history row, not 8")
    keys = [c.get("key") for c in cards]
    if len(set(keys)) != 8 or not all(keys):
        raise PayloadError(f"player {tag}: deck has empty or repeated cards {keys}")
    levels = [c.get("level") for c in cards]
    if not all(type(v) is int and v > 0 for v in levels):
        raise PayloadError(f"player {tag}: card levels missing {levels}")
    towers = side.get("towers") or []
    if (len(towers) != 1 or not towers[0].get("key")
            or type(towers[0].get("level")) is not int or towers[0]["level"] <= 0):
        raise PayloadError(f"player {tag}: tower troop or its level missing {towers}")
    hp = (side.get("hp") or [None])[0]
    if not hp:
        raise PayloadError(f"player {tag}: final tower hit points missing")
    hp = {k: _int(v) for k, v in hp.items()}
    if any(hp.get(k) is None for k in ("king", "princess0", "princess1", "total")):
        raise PayloadError(f"player {tag}: final tower hit points incomplete {hp}")
    if any(hp[k] < 0 for k in ("king", "princess0", "princess1", "total")):
        raise PayloadError(f"player {tag}: final tower hit points negative")
    if hp["total"] != hp["king"] + hp["princess0"] + hp["princess1"]:
        raise PayloadError(f"player {tag}: final tower hit points do not sum to total")
    return {
        "average_elixir": _stat(side, "Avg Elixir"),
        "deck": [{"card_key": c["key"], "level": c["level"], "name": c.get("name")} for c in cards],
        "elixir_leaked": _stat(side, "Elixir Leaked"),
        "final_tower_hitpoints": {"king": hp["king"], "princess_left": hp["princess0"],
                                  "princess_right": hp["princess1"], "total": hp["total"]},
        "four_card_cycle_elixir": _stat(side, "4-Card Cycle"),
        "name": names.get(tag),
        "tag": tag,
        "tower_card": {"card_key": towers[0]["key"], "level": towers[0]["level"],
                       "name": towers[0].get("name")},
    }


def _result(history: dict, team_tag: str, source_tag: str | None, tc: int, oc: int, warnings: list) -> str:
    """The team's result: the history row's label, turned round when the replay's
    team is not the player whose history it is; checked against the crowns."""
    by_crowns = "victory" if tc > oc else "defeat" if tc < oc else "draw"
    # challenge rows read 'Victory 8 wins': the first word is the result
    label = ((history.get("result") or "").strip().lower().split() or [""])[0]
    label = {"victory": "victory", "win": "victory", "defeat": "defeat", "loss": "defeat",
             "draw": "draw"}.get(label)
    # The label is the page owner's result. Find the owner's side by tag, not by position.
    owner = history.get("source_player_tag") or source_tag
    side_of = {}
    for i, side in enumerate(history.get("sides") or ()):
        for pl in side.get("players") or ():
            side_of[pl.get("tag")] = i
    if label is None or owner not in side_of or team_tag not in side_of:
        raise PayloadError("history result or its player's side is missing; cannot infer a result from crowns")
    if side_of[owner] != side_of[team_tag]:
        label = {"victory": "defeat", "defeat": "victory", "draw": "draw"}[label]
    if tc != oc and label != by_crowns:
        raise PayloadError(f"history result {label!r} disagrees with crowns {tc}-{oc}")
    return label


def build(record: dict) -> dict:
    """One record -> the payload. Raises PayloadError with the reason when the
    record cannot be replayed faithfully."""
    req = record.get("request") or {}
    tag = record.get("replay_tag") or req.get("tag")
    if not tag or req.get("tag") != tag:
        raise PayloadError("replay tag missing or not the one requested")
    try:
        response = json.loads(record["replay_response"])
    except (KeyError, TypeError, ValueError) as e:
        raise PayloadError(f"no readable /data/replay answer ({type(e).__name__})") from e
    if (not isinstance(response, dict) or response.get("success") is not True
            or not isinstance(response.get("html"), str) or not response["html"]):
        raise PayloadError("RoyaleAPI refused the replay (success false or no html)")
    p = ReplayHTML()
    p.feed(response["html"])
    if not p.replay_id or not p.timeline:
        text = " ".join(p.text)
        if "requires login" in text:
            raise PayloadError("replay answer says login is required")
        raise PayloadError("no replay timeline in the answer")
    if p.replay_id != tag:
        raise PayloadError(f"answer is for replay {p.replay_id}, not {tag}")
    end_tick, end_label = _clock_scale(p)

    # The map marker carries the point and data-i, the timeline card the ability
    # flag; they are the same events twice and join on (side, card, tick).
    timeline = defaultdict(deque)
    for a in p.timeline:
        s = {"blue": "t", "red": "o"}.get(a.get("data-s"))
        if s is None:
            raise PayloadError(f"timeline card on unknown side {a.get('data-s')!r}")
        timeline[(s, a.get("data-card"), _int(a.get("data-t")))].append(a)
    if len(p.markers) != len(p.timeline):
        raise PayloadError(f"{len(p.markers)} map markers but {len(p.timeline)} timeline cards")
    flags = {a.get("data-i") for a in p.markers}
    if len(flags) != 1 or next(iter(flags)) not in ("0", "1"):
        raise PayloadError(f"data-i is not one value 0/1 for the replay: {sorted(map(str, flags))}")
    data_i = int(next(iter(flags)))
    _check_side_marker(p.markers, data_i)

    team_tag = req.get("team_tags") or ""
    opp_tag = req.get("opponent_tags") or ""
    if "," in team_tag or "," in opp_tag:
        raise PayloadError("replay request is not a one-player-per-side battle")
    history = record.get("history") or {}
    buttons = history.get("replay_buttons")
    if buttons is not None:
        matching = [b for b in buttons if b.get("replay") == tag]
        if not matching:
            raise PayloadError("history row does not reference the requested replay")
        fields = {"teamTags": "team_tags", "opponentTags": "opponent_tags",
                  "teamCrowns": "team_crowns", "opponentCrowns": "opponent_crowns"}
        if not any(all(str(b.get(key)) == str(req.get(value)) for key, value in fields.items())
                   for b in matching):
            raise PayloadError("history replay parameters disagree with the request")
    sides = history.get("sides") or []
    if len(sides) != 2 or any(len(s.get("players") or []) != 1 for s in sides):
        raise PayloadError("history does not have exactly two single-player sides")
    by_tag = {}
    for side in history.get("sides") or ():
        for pl in side.get("players") or ():
            by_tag[pl.get("tag")] = side
    if (team_tag not in by_tag or opp_tag not in by_tag or team_tag == opp_tag
            or by_tag[team_tag] is by_tag[opp_tag]):
        raise PayloadError(f"replay players {team_tag}/{opp_tag} are not the history row's two sides")
    players = {"team": _player(by_tag[team_tag], team_tag),
               "opponent": _player(by_tag[opp_tag], opp_tag)}
    decks = {s: [c["card_key"] for c in players[s]["deck"]] for s in players}
    able = {s: sorted(k for k in decks[s] if k.endswith("-hero") or base_card(k) in CHAMPIONS)
            for s in decks}

    warnings: list[str] = []
    joined = []
    for order, a in enumerate(p.markers):
        w = a.get("data-s")
        if w not in ("t", "o"):
            raise PayloadError(f"map marker on unknown side {w!r}")
        key = (w, a.get("data-c"), _int(a.get("data-t")))
        if not timeline[key]:
            raise PayloadError(f"map marker {key} has no timeline card")
        joined.append((key[2], order, a, timeline[key].popleft()))
    unmatched = sum(len(q) for q in timeline.values())
    if unmatched:
        raise PayloadError(f"{unmatched} timeline cards have no map marker")
    joined.sort(key=lambda j: (j[0], j[1]))

    events, plays_n, ability_n = [], Counter(), Counter()
    for index, (tick, _order, m, tl) in enumerate(joined):
        side = "team" if m.get("data-s") == "t" else "opponent"
        if tick is None or tick < 1:
            raise PayloadError(f"event with tick {tick}")
        x, y = _int(m.get("data-x")), _int(m.get("data-y"))
        source = {"data_c": m.get("data-c"), "data_i": data_i, "data_s": m.get("data-s"),
                  "data_t": tick, "data_x": x, "data_y": y, "timeline_card_key": tl.get("data-card")}
        if tl.get("data-ability") not in ("0", "1"):
            raise PayloadError(f"event at tick {tick}: ability flag missing or invalid")
        if tl.get("data-ability") == "1":
            cands = able[side]
            if not cands:
                raise PayloadError(f"ability at tick {tick} ({side}) but no hero or champion in the deck")
            ability_n[(side, tuple(cands))] += 1
            events.append({
                "ability_source_authoritative": False, "ability_source_candidates": cands,
                "card_key": None, "card_play_number": ability_n[(side, tuple(cands))],
                "coordinates": None, "deck_card_key_candidates": [], "form_at_play": None,
                "kind": "activate_ability", "replay_tick_20hz": tick, "side": side,
                "source_fields": source, "source_index": index, "time_seconds": tick / TICKS_PER_SECOND})
            continue
        card = m.get("data-c")
        cands = [k for k in decks[side] if base_card(k) == card]
        if not cands:
            raise PayloadError(f"{side} played {card!r} at tick {tick}, which is not in its deck")
        if x is None or y is None:
            raise PayloadError(f"{side} play of {card} at tick {tick} has no point")
        coords = coordinates(x, y, data_i)
        if not coords["inside_18x32_arena"]:
            raise PayloadError(f"{side} play of {card} at tick {tick} lands outside the arena ({x}, {y})")
        plays_n[(side, card)] += 1
        events.append({
            "ability_source_authoritative": None, "ability_source_candidates": [],
            "card_key": card, "card_play_number": plays_n[(side, card)],
            "coordinates": coords, "deck_card_key_candidates": cands, "form_at_play": "unknown",
            "kind": "play_card", "replay_tick_20hz": tick, "side": side,
            "source_fields": source, "source_index": index, "time_seconds": tick / TICKS_PER_SECOND})
    if events and end_tick < events[-1]["replay_tick_20hz"]:
        raise PayloadError(f"end tick {end_tick} is before the last event {events[-1]['replay_tick_20hz']}")

    if len(p.tables) != 2:
        raise PayloadError(f"{len(p.tables)} elixir tables in the answer, not 2")
    stats = {"team": _elixir_table(p.tables[0]), "opponent": _elixir_table(p.tables[1])}
    agree = True
    for s in ("team", "opponent"):
        n_play = sum(1 for e in events if e["side"] == s and e["kind"] == "play_card")
        n_abil = sum(1 for e in events if e["side"] == s and e["kind"] == "activate_ability")
        if (stats[s].get("total") or [None])[0] != n_play or (stats[s].get("ability") or [None])[0] != n_abil:
            raise PayloadError(f"{s}: {n_play} plays / {n_abil} abilities, the elixir table says "
                               f"{(stats[s].get('total') or [None])[0]} / {(stats[s].get('ability') or [None])[0]}")

    tc, oc = _int(req.get("team_crowns")), _int(req.get("opponent_crowns"))
    if tc is None or oc is None or not 0 <= tc <= 3 or not 0 <= oc <= 3:
        raise PayloadError("crowns missing or outside 0..3 in the request")
    m = re.match(r"(\d+):(\d{2})$", end_label)
    payload = {
        "battle": {
            "battle_type": history.get("battle_type"),
            "game_mode": history.get("mode"),
            "opponent": {"crowns": oc, "players": [players["opponent"]]},
            # FirstLight_CR's names for when it was played and whose history it came from
            "played_at_utc": history.get("battle_time_utc"),
            "requested_player_tag": record.get("requested_player_tag"),
            "result": _result(history, team_tag, record.get("requested_player_tag"), tc, oc, warnings),
            "team": {"crowns": tc, "players": [players["team"]]},
        },
        "collection_schema_version": COLLECTION_SCHEMA,
        "events": events,
        "replay": {
            "aggregate_stats": stats,
            "card_counts": {s: {base_card(k): plays_n[(s, base_card(k))] for k in decks[s]}
                            for s in ("opponent", "team")},
            "duration": {"display_label": end_label,
                         "display_seconds": int(m[1]) * 60 + int(m[2]) if m else None,
                         "end_tick_20hz": end_tick,
                         "timeline_seconds": round(end_tick / TICKS_PER_SECOND, 2)},
        },
        "schema_version": SCHEMA,
        "source": {"anonymized": False, "fetched_at": record.get("fetched_at"),
                   "replay_tag": tag, "requested_player_tag": record.get("requested_player_tag"),
                   "site": "RoyaleAPI"},
        "validation": {
            "ability_event_count": sum(e["kind"] == "activate_ability" for e in events),
            "coordinate_event_count": sum(e["coordinates"] is not None for e in events),
            "elixir_table_counts_agree": agree,
            "map_marker_count": len(p.markers),
            "normalized_event_count": len(events),
            "timeline_event_count": len(p.timeline),
            "unmatched_timeline_event_count": unmatched,
        },
    }
    if warnings:
        payload["warnings"] = warnings
    return payload


ACTION_SCHEMA = "royaleapi-replay-parquet.v1"


def action_rows(payload: dict, replay_tag: str | None = None) -> list[dict]:
    """The payload's events as IL_Replay `actions` rows (one per event)."""
    tag = replay_tag or payload["source"]["replay_tag"]
    rows = []
    for i, e in enumerate(payload["events"]):
        c = e.get("coordinates") or {}
        rows.append({
            "schema_version": ACTION_SCHEMA, "replay_tag": tag, "event_index": i,
            "source_index": e["source_index"], "kind": e["kind"], "side": e["side"],
            "card_key": e["card_key"], "card_play_number": e["card_play_number"],
            "replay_tick_20hz": e["replay_tick_20hz"], "time_seconds": e["time_seconds"],
            "form_at_play": e["form_at_play"],
            "ability_source_authoritative": e["ability_source_authoritative"],
            "native_x": (c.get("native_world_units") or {}).get("x"),
            "native_y": (c.get("native_world_units") or {}).get("y"),
            "grid_x": (c.get("grid_cell_floor") or {}).get("x"),
            "grid_y": (c.get("grid_cell_floor") or {}).get("y"),
            "arena_column": (c.get("arena_label_from_blue") or {}).get("column"),
            "arena_row": (c.get("arena_label_from_blue") or {}).get("row"),
            "deck_card_key_candidates": e["deck_card_key_candidates"],
            "ability_source_candidates": e["ability_source_candidates"],
            "event_json": json.dumps(e, sort_keys=True, ensure_ascii=False, separators=(",", ":")),
        })
    return rows
