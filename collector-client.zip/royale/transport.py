"""How this scraper talks to RoyaleAPI.

Cloudflare fingerprints the TLS/HTTP2 handshake, so a cf_clearance cookie is
only honoured for the client that earned it. Handing the browser's clearance to
an outside HTTP client no longer works at all -- curl carrying a fresh
clearance is answered 403 on every path, public ones included. So every request
is issued as a fetch() from inside the page that holds the pass.

Pages   headful Chromium, and the fetch engine. Two contexts share one browser:
        `anon` for public pages, `auth` carrying the RoyaleAPI session cookie
        for the login-gated /data/replay. Public crawling stays anonymous, and
        the account is only ever exposed on the requests that require it.

Client  requests, retries and the shared rate Limiter. Sync Playwright is
        pinned to the thread that created it, so fetches cannot be spread over
        a thread pool; concurrency comes from Promise.all inside the page
        instead. That is why the primitive here is get_many, not get.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from datetime import timezone
from email.utils import parsedate_to_datetime
from typing import Callable
from urllib.parse import parse_qs, urlencode, urlsplit

from playwright.sync_api import sync_playwright

from .cookies import SESSION_COOKIE, Session
from .limiter import Limiter

BASE = "https://royaleapi.com"
SKIP = ("image", "font", "media", "stylesheet")  # nothing we parse needs these
RETRIES = 10     # per request, all of them 429 backoffs handed to the Limiter
RENEWALS = 6     # 403s we try to fix by re-solving the challenge before giving up
CHALLENGE_WAIT_MS = 300_000   # a check that needs a click waits this long for the person

# Runs in the page, same origin, so the browser attaches that context's cookies
# and uses the handshake the clearance was issued for. One failed URL must not
# sink the batch, hence the per-request catch.
_FETCH_JS = """async (urls) => Promise.all(urls.map(async (u) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 45000);
    try {
        // Redirects are followed (RoyaleAPI redirects within its own site, e.g. a history
        // cursor), but an answer that ends up on another origin is not read: status -1.
        const r = await fetch(u, {credentials: 'include', redirect: 'follow', signal: controller.signal});
        if (new URL(r.url).origin !== location.origin) {
            return [-1, r.url, '', ''];
        }
        return [r.status, r.url, await r.text(), r.headers.get('retry-after') || ''];
    } catch (e) {
        return [0, u, String(e), ''];
    } finally {
        clearTimeout(timer);
    }
}))"""


# True on Cloudflare's check page: its English title, or the options object that only the
# check page defines (normal pages carry a different Cloudflare script), so a localised
# title is caught too.
_CHALLENGE_JS = ("document.title.startsWith('Just a moment') || "
                 "typeof window._cf_chl_opt !== 'undefined'")


def refusal(body: str) -> str | None:
    """'login' or 'challenge' when a 200 answer is really RoyaleAPI refusing: its battle
    history says it needs a login, or Cloudflare served its check page. Otherwise None.
    Such a page parses to no battles and no next page, so taking it at face value would
    mark a player done with nothing read."""
    head = (body or "")[:20000]
    if "This feature requires login" in head:
        return "login"
    # titles only: Cloudflare injects its challenge-platform script into normal pages too
    if ("<title>Just a moment" in head or "<title>Attention Required" in head
            or re.search(r"window\._cf_chl_opt\s*=", head)):   # the check page's own setup
        return "challenge"
    return None


def retry_after_seconds(value: str, now: float | None = None) -> float:
    """Retry-After accepts either integer seconds or an HTTP-date (RFC 9110)."""
    value = str(value or "").strip()
    if value.isascii() and value.isdigit():
        return float(value)
    try:
        date = parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        return max(0.0, date.timestamp() - (time.time() if now is None else now))
    except (TypeError, ValueError, OverflowError):
        return 0.0


class RateLimited(RuntimeError):
    """A request that never came back cleanly after every retry: `status` is what it last
    got - 429 (rate limited throughout) or 0 (no answer at all)."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class ClearanceExpired(RuntimeError):
    """403: the Cloudflare pass died and re-solving it did not help."""


class AuthError(RuntimeError):
    """Cloudflare or the login gate turned us away for good."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class ChallengeUnsolved(ClearanceExpired):
    """403, and Cloudflare's check opened in the browser never cleared (nobody ticked it, the
    tab was closed, or the site kept refusing). Every next request would wait for it again."""


class Pages:
    """The browser. Single-threaded: playwright's sync API is."""

    def __init__(self, session: Session | None = None):
        if sys.platform.startswith("linux") and not (
                os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            raise AuthError("no display: the browser must run headful to clear Cloudflare")
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch(
            headless=False, args=["--disable-blink-features=AutomationControlled"])
        self.anon = self._context()
        # The pass is bound to IP, UA and handshake, all of which the two contexts
        # share -- so the logged-in one is handed the clearance the anonymous one
        # already earned instead of sitting through a second challenge.
        self.auth = (self._context(session, self._clearance(self.anon))
                     if session else self.anon)

    def _context(self, session: Session | None = None, clearance: list | None = None):
        ctx = self._browser.new_context()
        cookies = list(clearance or [])
        if session:
            cookies.append({"name": SESSION_COOKIE, "value": session.value,
                            "domain": ".royaleapi.com", "path": "/",
                            "secure": True, "httpOnly": True})
        if cookies:
            ctx.add_cookies(cookies)
        page = ctx.new_page()
        page.route("**/*", lambda r: r.abort() if r.request.resource_type in SKIP
                   else r.continue_())
        self._solve(page, ctx)
        return page

    @staticmethod
    def _clearance(page) -> list:
        return [c for c in page.context.cookies() if c["name"] == "cf_clearance"]

    @staticmethod
    def _challenged(page) -> bool:
        """Cloudflare's check page, by its English title or, for a localised one, by the
        challenge options object only that page defines."""
        try:
            return bool(page.evaluate(f"() => {_CHALLENGE_JS}"))
        except Exception:  # noqa: BLE001 -- page mid-navigation: judge by the title
            return page.title().startswith("Just a moment")

    @staticmethod
    def _solve(page, ctx, tries: int = 3, target: str | None = None) -> None:
        """Open `target` (default: the home page) in the page, letting the browser run
        Cloudflare's check if one is shown.

        A check served to an in-page fetch() cannot run there: it only runs when the page
        itself opens the challenged address. So a 403 renewal opens that address, not the
        home page, which Cloudflare may let straight through while still challenging the
        data pages. The check usually clears by itself in seconds; if it asks for a click,
        the person at the collector's Chrome window does it. A stall is retried.

        Success is judged by the page, not by a cf_clearance cookie: a profile Cloudflare
        lets straight through has no cookie, and an old cookie proves nothing."""
        last = ""
        address = target or f"{BASE}/"
        for attempt in range(tries):
            try:
                if target:
                    # The check may need a person: show this tab, not the one in front.
                    page.bring_to_front()
                page.goto(address, wait_until="domcontentloaded", timeout=60_000)
                if Pages._challenged(page):
                    print("  Cloudflare check in the collector's Chrome window (its tab is now "
                          "in front); it usually clears by itself. If it shows a checkbox, "
                          "tick it there.", flush=True)
                    page.wait_for_function(f"() => !({_CHALLENGE_JS})",
                                           polling=1000, timeout=CHALLENGE_WAIT_MS)
                title = page.title()
                host = urlsplit(page.url).hostname or ""
                blocked = Pages._challenged(page) or any(
                    mark in title for mark in ("Attention Required", "Access denied", "blocked"))
                if not blocked and (host == "royaleapi.com" or host.endswith(".royaleapi.com")):
                    return
                last = f"page title {title[:80]!r} at {host or page.url[:60]}"
            except Exception as e:  # timeout or navigation error: worth one more go
                last = str(e).split("\n")[0]
            if attempt < tries - 1:
                try:
                    page.wait_for_timeout(5_000)
                except Exception as e:  # tab or browser closed: the check cannot clear
                    last = str(e).split("\n")[0]
                    break
        raise AuthError(f"Cloudflare challenge never cleared after {tries} tries ({last}). "
                        "Wait a minute and rerun; if it persists, open royaleapi.com in "
                        "your own browser first.")

    def renew(self, auth: bool, address: str | None = None) -> None:
        """Re-solve the challenge for one context after a 403, on a page standing in for
        the address that got it (see renewal_address)."""
        page = self.auth if auth else self.anon
        self._solve(page, page.context,
                    target=renewal_address(address) if address else None)

    def fetch(self, urls: list[str], auth: bool = False) -> list[list]:
        """[status, final_url, body] per URL, fetched concurrently in the page."""
        page = self.auth if auth else self.anon
        trace = os.environ.get("CR_COLLECTOR_TRACE") == "1"
        started = time.monotonic()
        if trace:
            print(f"  request: {len(urls)} URL(s), {'auth' if auth else 'history'} page, "
                  f"{urlsplit(urls[0]).path if urls else '/'}", flush=True)
        results = page.evaluate(_FETCH_JS, urls)
        if trace:
            print(f"  response: HTTP {[r[0] for r in results]}, "
                  f"{time.monotonic() - started:.1f}s, "
                  f"refusal={[refusal(r[2]) for r in results]}", flush=True)
        return results

    def close(self) -> None:
        self._browser.close()
        self._pw.stop()


def renewal_address(address: str) -> str:
    """The page to open so the browser can run Cloudflare's check after a 403 on `address`.

    A history page is opened itself. /data/replay never is: opening it would be one more
    replay request outside the replay pace, with its answer unread. Its referrer -- the
    player's battles page, an ordinary page of the same site -- stands in, or else the
    home page."""
    parts = urlsplit(address)
    if parts.path != "/data/replay":
        return url(address)
    referrer = parse_qs(parts.query).get("referrer_path", [""])[0]
    # Only the exact battles-page shape is opened: tags come from page HTML, and a dot
    # segment or doubled slash could otherwise steer the browser back to /data/replay.
    if re.fullmatch(re.escape(BASE) + r"/player/[0-9A-Za-z]+/battles", referrer):
        return referrer
    return f"{BASE}/"


def url(path: str, params: dict | None = None) -> str:
    full = path if path.startswith("http") else f"{BASE}{path}"
    parts = urlsplit(full)
    if (parts.scheme != "https" or parts.hostname != "royaleapi.com"
            or parts.port not in (None, 443) or parts.username or parts.password):
        raise AuthError("refusing a data request outside https://royaleapi.com")
    return f"{full}?{urlencode(params)}" if params else full


class Client:
    """Rate-limited fetching. Call get_many for anything you have more than one
    of -- a batch is a single round trip into the page and the requests inside
    it genuinely overlap."""

    def __init__(self, pages: Pages, limiter: Limiter | None = None, batch: int = 6,
                 batch_interval: float = 0.0, recover_batch: bool = True):
        self.pages = pages
        self.limiter = limiter or Limiter()
        self.batch = batch
        self._live = batch  # effective burst, shrunk by 429s and rebuilt slowly
        self.batch_interval = batch_interval
        self.recover_batch = recover_batch
        self._next_batch_at = 0.0

    def get_many(self, paths: list[str], auth: bool = False,
                 tick: Callable[[], None] | None = None) -> list[str | Exception]:
        """Bodies in the order asked. A failed request yields its exception in
        place, so one dead page never costs the rest of the batch.

        The Limiter fixes the average rate, but a batch fires at once, and a
        burst is what /data/replay actually objects to. So the burst width is
        itself adaptive: halved on any 429, widened one slot per clean batch.
        `tick` fires once per request that reaches a final answer -- retries do
        not tick, so a progress bar counts real progress.
        """
        out: list[str | Exception] = [None] * len(paths)  # type: ignore[list-item]
        pending = list(enumerate(paths))
        renewals = 0
        last_status: dict[int, int] = {}   # what a request still pending last got

        def settle(idx: int, value) -> None:
            out[idx] = value
            if tick:
                tick()

        for _ in range(RETRIES):
            if not pending:
                break
            retry: list[tuple[int, str]] = []
            i = 0
            while i < len(pending):
                chunk = pending[i:i + max(1, self._live)]
                i += len(chunk)
                acquire_for = getattr(self.limiter, "acquire_for", None)
                for _idx, slot_path in chunk:
                    if acquire_for is not None:
                        acquire_for(url(slot_path))   # the limiter may pace by endpoint
                    else:
                        self.limiter.acquire()
                while True:
                    remaining = self._next_batch_at - time.monotonic()
                    if remaining <= 0:
                        break
                    time.sleep(remaining)
                results = self.pages.fetch([url(p) for _, p in chunk], auth)
                self._next_batch_at = time.monotonic() + self.batch_interval
                blocked, wait = False, 0.0
                for (idx, path), (status, final, body, retry_after) in zip(chunk, results):
                    last_status[idx] = status
                    if status == -1:
                        settle(idx, AuthError(f"{path} was redirected off royaleapi.com to {final}",
                                              status=-1))
                    elif status == 429:
                        blocked = True
                        wait = max(wait, retry_after_seconds(retry_after))
                        retry.append((idx, path))
                    elif status == 403:
                        if renewals < RENEWALS:
                            renewals += 1
                            if os.environ.get("CR_COLLECTOR_TRACE") == "1":
                                print(f"  HTTP 403: refreshing the source page ({renewals}/{RENEWALS})",
                                      flush=True)
                            try:
                                self.pages.renew(auth, url(path))
                            except AuthError as exc:
                                # The check never cleared (nobody ticked the box, or the
                                # site kept refusing): a connection-level refusal, not a
                                # problem with this player. Stop renewing.
                                renewals = RENEWALS
                                settle(idx, ChallengeUnsolved(f"403 on {path}; {exc}"))
                            else:
                                retry.append((idx, path))
                        else:
                            settle(idx, ClearanceExpired(f"403 on {path}"))
                    elif status == 0:
                        retry.append((idx, path))  # network wobble: try again
                    elif status != 200:
                        settle(idx, AuthError(f"HTTP {status} on {path}", status=status))
                    elif refusal(body) == "challenge":
                        settle(idx, ClearanceExpired(f"Cloudflare challenge on {path}"))
                    elif refusal(body) == "login" or ("/login" in final and "/login" not in path):
                        settle(idx, AuthError(f"{path} redirected to the login page"))
                    else:
                        settle(idx, body)
                if blocked:
                    self._live = max(1, self._live // 2)
                    cooldown = self.limiter.blocked(wait)
                    print(f"  HTTP 429: waiting {cooldown:.0f}s (Retry-After={wait:g}s); "
                          f"batch={self._live}", flush=True)
                elif all(status == 200 and refusal(body) is None and "/login" not in final
                         for status, final, body, _ in results):
                    if self.recover_batch:
                        self._live = min(self.batch, self._live + 1)
                    self.limiter.ok()
            pending = retry

        for idx, path in pending:
            status = last_status.get(idx)
            what = "HTTP 429 every time" if status == 429 else "no answer (connection failed)"
            settle(idx, RateLimited(f"{path} never came back cleanly: {what}", status=status))
        return out

    def get(self, path: str, params: dict | None = None, auth: bool = False) -> str:
        res = self.get_many([url(path, params)], auth)[0]
        if isinstance(res, Exception):
            raise res
        return res

    def json(self, path: str, params: dict | None = None) -> dict:
        return json.loads(self.get(path, params, auth=True))

    def logged_in(self) -> bool:
        """/me answers 200 for a real session and redirects to /login otherwise."""
        status, final, _, _ = self.pages.fetch([url("/me")], auth=True)[0]
        return status == 200 and "/login" not in final
