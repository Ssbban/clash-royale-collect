#!/bin/bash
# Mac: double-click this. It sets up what it needs the first time, then collects.
# Everything stays in this folder: .venv/ for Python packages, data/ for the database.
# Remote machines use --join https://YOUR-HOST and wait for local approval.
cd "$(dirname "$0")"
echo "Clash Royale replay collector"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is needed. Install it from https://www.python.org/downloads/ and"
  echo "then double-click this file again."
  read -n 1 -s -r -p "Press any key to close."
  exit 1
fi

if [ ! -d .venv ]; then
  echo "First run: setting up (a few minutes, one time only)..."
  python3 -m venv .venv
  ./.venv/bin/pip install -q --upgrade pip
  ./.venv/bin/pip install -q playwright beautifulsoup4 lxml pyarrow huggingface_hub
fi
# Uses the Google Chrome already installed on this computer; nothing is downloaded.

echo
echo "Use --no-client for coordinator only, or --join https://YOUR-HOST on another PC."
echo "Collection opens Chrome after this machine has been approved."
echo

./.venv/bin/python coordinator/run_local.py "$@"
result=$?
echo
read -n 1 -s -r -p "Stopped. Run this again to continue where it left off. Press any key to close."
exit "$result"
