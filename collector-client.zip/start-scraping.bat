@echo off
REM Windows: double-click this. Sets up what it needs the first time, then collects.
REM Everything stays in this folder: .venv\ for Python packages, data\ for the database.
REM Remote machines use --join https://YOUR-HOST and wait for local approval.
setlocal enabledelayedexpansion
cd /d "%~dp0"
echo Clash Royale replay collector
echo.

REM The "py" launcher is the reliable one. Plain "python" on Windows is often a
REM Microsoft Store stub that opens the Store instead of running anything.
set PY=
py -3 --version >nul 2>&1 && set PY=py -3
if "%PY%"=="" (
  python --version >nul 2>&1 && set PY=python
)
if "%PY%"=="" (
  echo Python 3 is needed. Install it from https://www.python.org/downloads/
  echo IMPORTANT: tick "Add Python to PATH" in the installer, then run this again.
  pause
  exit /b 1
)

if not exist .venv (
  echo First run: installing the Python packages. This takes a few minutes.
  echo It only happens once.
  %PY% -m venv .venv
  .venv\Scripts\python -m pip install -q --upgrade pip
  .venv\Scripts\python -m pip install -q playwright beautifulsoup4 lxml pyarrow huggingface_hub
)
REM Uses the Google Chrome already installed on this computer; nothing is downloaded.

echo.
echo Another PC: run join-cloud.bat the first time; after that this file reuses its saved
echo cloud connection. --local runs this PC's own local coordinator, --no-client only that.
echo Collection opens Chrome after this machine has been approved.
echo.

.venv\Scripts\python coordinator\run_local.py %*
set RESULT=%ERRORLEVEL%
echo.
echo Stopped. Run this again to continue where it left off.
pause
exit /b %RESULT%
