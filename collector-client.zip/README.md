# Clash Royale replay collector（自用版）

基于 [arronwang01/cr-collector](https://github.com/arronwang01/cr-collector) 的采集器和协调器。
协调器已部署在用户自己的 Cloudflare 账号；多台电脑共享任务、去重记录和原始数据。
原仓库没有许可证文件，请保持此副本私用。

## 当前完成范围

机器申请、审批、撤销、共享任务、续租、回放预留和失败恢复已经实现。
固定入口：**https://cr-coordinator.mingjiali129.workers.dev**。
Python Worker、D1 和私有 R2 已部署。本机不需要一直开机，也不需要 VPS、Tunnel 或自有域名。

## 架构与数据去向

```text
电脑 A 的采集器 ─┐
电脑 B 的采集器 ─┼─ HTTPS → Cloudflare Python Worker
电脑 C 的采集器 ─┘                 ├─ D1 replay-db：任务、去重、机器状态
                                  └─ 私有 R2 cr-replay-raw：压缩原始记录
                                             │
                                  管理员下载校验 → 本地导出 → 用户 HF
```

- Worker 本身就是协调器，直接访问 D1 `replay-db` 和私有 R2 `cr-replay-raw`。
  不需要本机端口、隧道或本地服务器；其他采集电脑不依赖这台电脑在线。
- D1 保存任务、机器、租约和去重索引，R2 保存 gzip 原始回放及历史页对局行。
  R2 公共访问关闭；先确认对象写入，再提交 D1 索引，读回时核对 SHA-256。
- 管理命令通过固定 HTTPS 入口认证，云端只保存专用管理员 token 的哈希。
- 每台采集器使用独立 token。服务器只保存它的哈希；显示名称不决定身份。
  未批准的机器只能申请/查询自己的申请，不能领任务或提交数据。
- 申请最多保留 32 个待审批项，15 分钟过期，有请求频率限制。
  申请密钥与机器 token 在首次请求前就保存到本机，丢失响应可安全重试。
- 所有业务接口，包括状态和过滤设置，都要求认证。两条申请接口是受限的启动入口。
- 客户端只接受回环 HTTP 或用 `--join` 明确固定的 HTTPS origin；不接受公网 HTTP、
  URL 中的凭据、第三方重定向或上游采集服务器。请求不使用环境代理。
- 数据流向是本地、用户自己的 Cloudflare 资源，以及显式上传时的用户 HF 仓库。
  Cloudflare 提供计算和存储，并非仅转发。Worker 没有开启请求日志或分析导出。
  源站访问仍涉及 RoyaleAPI 及其验证服务。
- 浏览器使用自己的 `~/.cr-scraper/browser`，只允许 RoyaleAPI、其资源子域和
  `challenges.cloudflare.com`，以及 Discord 登录和 hCaptcha 所需域名。
  登录凭据和 token 不写入对局、导出或分发包。
- 只有显式执行上传脚本，才会将指定导出文件发往 Hugging Face 的
  `Sslmj/cr-replaydata`。采集和导出不会自动上传。

## 在这台电脑开始采集

双击 **`start-cloud.bat`**。它使用已批准的 `data/cloud-machine.json` 连接云端，
不启动本地协调器。出现 RoyaleAPI 登录或验证页面时，在采集浏览器中手动完成。

管理员操作在项目目录执行：

```bat
.venv\Scripts\python coordinator\cloud.py --stats
.venv\Scripts\python coordinator\cloud.py --machines
.venv\Scripts\python coordinator\cloud.py --approve ABC234
.venv\Scripts\python coordinator\cloud.py --revoke m_MACHINE_ID
.venv\Scripts\python coordinator\cloud.py --add-players tags.txt
.venv\Scripts\python coordinator\cloud.py --failures
.venv\Scripts\python coordinator\cloud.py --retry-failed --stats
```

`--machines` 显示申请码、机器 ID、状态和进度；撤销使用机器 ID。
管理员凭据保存在忽略提交的 `data/cloud-admin.json`，只留在这台管理电脑上。
它与旧的本地协调器凭据相互独立；不要分发整个项目目录。

## 让另一台电脑加入

将 **`data/collector-client.zip`** 解压到另一台自己的电脑，安装 Python 3 和 Google Chrome，
双击 **`join-cloud.bat`**。首次安装依赖后会显示六位申请码并等待批准。
在管理电脑执行上面的 `--approve` 命令后，采集器才打开浏览器。

可选机器名称及只申请不采集：

```bat
join-cloud.bat --machine-name laptop-b
join-cloud.bat --machine-name laptop-b --join-only
```

Mac 使用：

```sh
./start-scraping.command --join https://cr-coordinator.mingjiali129.workers.dev --machine-name mac-b
```

再次运行相同命令会复用该机器的连接。连接保存在 `~/.cr-scraper/connection.json`，
不要将它或浏览器目录复制给另一台机器。每台电脑独立登录及处理源站验证。
分发包不包含云端管理员脚本、数据库、token、浏览器资料或日志。

## 不重复、不伪造、可补抓

- 每个玩家有唯一租约和随机 lease_id，只有当前机器能提交、失败或释放任务。
  后台每 30 秒续租，包括 RoyaleAPI 验证等待和 429 冷却期间；失联超过 15 分钟可被重新领取。
  旧采集器不能提交或完成已经转交的任务。
- 下载回放前原子预留 replay tag。两名对手可能在不同机器上扫描；
  碰到别人正在抓的回放时，该玩家回到待处理，不会被当成完成。
  中断或租约过期后可能重新下载，这是恢复缺失数据所需的重试；有效数据写入仍去重。
- 每批保存都明确使用 `complete=false`。只有历史扫描和所有所需回放成功结束后才单独完成玩家。
  未保存的预留回放、解析错误、验证失败或 HTTP 失败都不能靠空提交标记完成。
- 已抓到的原始记录先同步写入本机 `~/.cr-scraper/outbox`，云端确认后才删除。
  断网或进程退出后可继续提交，缓存与回放请求参数严格匹配。云端每次接收最多一场。
- 有效回放保留；无效原始记录隔离，不进入成功列表，后续有效抓取可修复。
  普通失败记录在 `--failures`，用 `--retry-failed --stats` 重新排队。
  账号或连接级拒绝会停止该采集器并释放当前任务。
- 新抓取保留回放原始响应和历史页对局 HTML 行，包括卡牌等级、塔兵种/等级、
  六座塔终局血量等可获得字段。缺失或矛盾的数据不编造。
  旧导入数据缺失的原始历史行不会被事后伪造。
- 检查能拒绝已知矛盾，不能证明源站本身永远正确。原始证据供后续审计。

源站失败诊断仅保存在本机 `~/.cr-scraper/diagnostics/`：包含失败响应正文、HTTP 状态、
Retry-After，以及最近 30 次响应的时间、耗时和状态。不记录 Cookie、请求头或完整查询 URL，
不上传协调器、R2 或 HF。`success:false` 只说明网站拒绝了该次回放请求，不能单独证明封禁。

每名玩家最多扫描 20 页。每台电脑的 RoyaleAPI 请求排成一条队列：
回放请求（`/data/replay`，含重试）两次开始时间至少相隔 60 秒，这是防止回放接口限流的关键；
其余数据请求（历史页）与前一个请求相隔 8–10 秒的随机值。打开页面（启动、登录页、Cloudflare 重新验证）不受此限制。
协调器配置只能把回放间隔调得更长（高于 60 秒时在其 min–max 之间随机），不能低于 60 秒。
上传到协调器单独计时，每次间隔 5 秒，重试也遵守。
源站 HTTP 429 从 60 秒开始退避，连续限流时最长退避 900 秒，更长的 Retry-After 优先。
冷却期限和下一次允许请求的时间都跨重启保存，停下后马上重开也会先等满剩余间隔。
等待期间浏览器照常响应（登录、验证不会卡住）。窗口中每个请求打印一行时间和类型，便于确认没有卡住。
按这个速度，一名玩家 20 页历史约 3 分钟，其后每场新回放约 1 分钟。

## 迁移、核对与导出

```bat
.venv\Scripts\python coordinator\cloud.py --migrate data\work.db
.venv\Scripts\python coordinator\cloud.py --verify data\work.db
.venv\Scripts\python coordinator\cloud.py --download data\cloud-cache.db
.venv\Scripts\python coordinator\export_hf.py --db data\cloud-cache.db --out data\hf-export
.venv\Scripts\python coordinator\upload_hf.py --folder data\hf-export --repo Sslmj/cr-replaydata
```

迁移首次创建来源快照，在 `data/cloud-migration-*.json` 保存断点。
原数据库不修改；全部回放确认后才迁移玩家状态。中断后运行同一命令续传。
`--verify` 比较来源中所有记录的 SHA-256，并从 R2 抽样读回。
迁移时先不要开启云端采集器，以免与旧任务状态导入交错。

下载逐条核验原始 SHA-256，保存到本地缓存库；再次下载会重新扫描云端，以发现修复记录。
导出仅包含有效回放，生成 `replays/`、`actions/`、`sources/` parquet，
每部分 5,000 场，并读回核对数量和唯一性。采集、迁移、下载和导出均不会自动上传 HF。

## 维护与部署

云端代码在 `cloudflare/`。Python Worker 复用 `royale/payload.py` 和 `royale/parse.py` 验证数据，
D1 表结构在 `cloudflare/migrations/`。`wrangler.jsonc` 记录资源绑定，无明文 token。

```powershell
# 项目根目录，生成验证模块并检查本地逻辑
.venv\Scripts\python cloudflare\build.py
.venv\Scripts\python -m pytest -q
.venv\Scripts\python tools\package_collector.py

# 已配置 Wrangler OAuth 的管理电脑，使用项目中安装的 uv
cd cloudflare
$env:WRANGLER_SEND_METRICS='false'
$env:PATH=(Join-Path (Get-Location) '.venv\Scripts')+';'+$env:PATH
.venv\Scripts\uv.exe run pywrangler deploy
```

首次部署到新资源时，需先应用 D1 migrations、绑定私有 R2，并设置 `ADMIN_TOKEN_HASH` secret。
该值是本机专用管理员 token 的 SHA-256；不要将 token 放入代码、命令参数、截图或聊天。
本地集成检查 `tools/check_cloudflare_local.py` 只连接 `127.0.0.1:8799`，不向生产添加测试任务。
Cloudflare 服务受账户套餐额度约束；本项目没有自动购买升级。

分发包 `data/collector-client.zip` 只包含列明的源代码、启动器和说明，
不包含数据库、token、浏览器资料、日志、导出文件或本机配置。

## 保留的本地模式

`start-scraping.bat`（不带 `--join`）仍启动本地协调器和采集器，写入 `data/work.db`。
`--no-client` 只运行本地协调器；管理命令是 `coordinator/run_local.py`。
这套本地队列与云端队列独立。现在的多机收集请使用 `start-cloud.bat` / `join-cloud.bat`。
